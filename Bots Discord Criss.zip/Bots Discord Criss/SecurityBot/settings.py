"""Utilidades para leer y guardar config.json de forma segura."""
import json
import os
import threading

_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
_lock = threading.Lock()


def load():
    with open(_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save(cfg):
    with _lock:
        tmp = _PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
        os.replace(tmp, _PATH)


# alias para importar como save_config en otros módulos
save_config = save


def guild_conf(cfg, guild_id):
    """Devuelve (y crea si falta) la configuración de un servidor."""
    key = str(guild_id)
    cfg.setdefault("guilds", {}).setdefault(key, {})
    return cfg["guilds"][key]
