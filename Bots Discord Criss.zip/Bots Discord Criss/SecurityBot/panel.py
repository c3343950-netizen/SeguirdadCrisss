"""
Panel web de administración para SecurityBot.

- Se inicia automáticamente junto con el bot (hilo aparte).
- Acceso: http://127.0.0.1:5000  (host/puerto en config.json)
- Contraseña: campo "panel_password" de config.json

Funciones:
- Ver los servidores donde está el bot.
- Enviar mensajes a un canal específico (texto normal o embed).
- Enviar mensajes privados (MD) a un usuario concreto.
- Anunciar por MD a todos los miembros de un rol (con límite de seguridad).
"""
import secrets
import time
from collections import defaultdict, deque

import discord
from flask import Flask, flash, redirect, render_template_string, request, session, url_for

from settings import save as save_config

app = Flask(__name__)
app.url_map.strict_slashes = False
BOT = None

MAX_SENDS_PER_MINUTE = 20
MAX_BROADCAST = 200
MAX_MSG_LEN = 2000

_send_times = deque()
_login_fails = defaultdict(list)  # ip -> [timestamps]

COLORS = {
    "azul": 0x3498DB,
    "rojo": 0xE74C3C,
    "verde": 0x2ECC71,
    "amarillo": 0xF1C40F,
    "morado": 0x9B59B6,
    "naranja": 0xE67E22,
    "gris": 0x95A5A6,
}


# ----------------------------------------------------------------- arranque
def run_panel(bot):
    global BOT
    BOT = bot
    cfg = bot.config
    app.secret_key = _ensure_secret(cfg)
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    host = cfg.get("panel_host", "127.0.0.1")
    port = int(cfg.get("panel_port", 5000))
    print(f"[PANEL] Panel web listo -> http://{'127.0.0.1' if host == '0.0.0.0' else host}:{port}")
    app.run(host=host, port=port, debug=False, use_reloader=False)


def _ensure_secret(cfg):
    secret = cfg.get("panel_secret")
    if not secret:
        secret = secrets.token_hex(32)
        cfg["panel_secret"] = secret
        save_config(cfg)
    return secret


# ------------------------------------------------------------------ helpers
def _logged():
    return session.get("panel_login") is True


def _guard():
    if not _logged():
        return redirect(url_for("login"))
    return None


def _rate_limited():
    now = time.monotonic()
    while _send_times and now - _send_times[0] > 60:
        _send_times.popleft()
    if len(_send_times) >= MAX_SENDS_PER_MINUTE:
        return True
    _send_times.append(now)
    return False


def _login_blocked(ip):
    now = time.time()
    _login_fails[ip] = [t for t in _login_fails[ip] if now - t < 600]
    return len(_login_fails[ip]) >= 8


def _register_fail(ip):
    _login_fails[ip].append(time.time())


def _page(content_tpl, **ctx):
    """Compone el contenido con el layout base (sin extends de Jinja)."""
    content = render_template_string(content_tpl, **ctx)
    return render_template_string(
        BASE, css=CSS, content=content,
        host=BOT.config.get("panel_host", "127.0.0.1"),
        port=BOT.config.get("panel_port", 5000),
    )


# ---------------------------------------------------------------- plantillas
CSS = """
:root{--bg:#0f172a;--card:#1e293b;--acc:#38bdf8;--txt:#e2e8f0;--mut:#94a3b8}
*{box-sizing:border-box}
body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--txt)}
header{display:flex;justify-content:space-between;align-items:center;padding:14px 28px;background:#0b1220;border-bottom:1px solid #233247}
header h1{margin:0;font-size:20px}
header a{color:var(--acc);text-decoration:none;margin-right:14px}
button.logout{background:#334155;color:#fff;border:0;padding:8px 14px;border-radius:8px;cursor:pointer}
main{max-width:1000px;margin:24px auto;padding:0 16px}
.card{background:var(--card);border:1px solid #2c3e55;border-radius:12px;padding:20px;margin-bottom:20px}
.card h2{margin-top:0;font-size:17px}
label{display:block;margin:10px 0 4px;color:var(--mut);font-size:13px}
input[type=text],input[type=password],input[type=number],select,textarea{width:100%;padding:10px;border-radius:8px;border:1px solid #375074;background:#0b1220;color:var(--txt);font-size:14px}
textarea{min-height:90px;resize:vertical}
button.send{margin-top:14px;background:var(--acc);color:#06202f;font-weight:700;border:0;padding:10px 18px;border-radius:8px;cursor:pointer}
button.danger{background:#ef4444;color:#fff}
.row{display:flex;gap:16px;flex-wrap:wrap}.row>div{flex:1;min-width:240px}
.flash{padding:10px 14px;border-radius:8px;margin-bottom:14px;background:#14351f;color:#86efac;border:1px solid #1f5c33}
.flash.err{background:#3a1420;color:#fda4af;border-color:#6c2238}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:6px 8px;border-bottom:1px solid #2c3e55;color:var(--mut)}
th{color:var(--txt)}
.gcard{display:inline-block;background:var(--card);border:1px solid #2c3e55;border-radius:12px;padding:16px;margin:0 12px 12px 0;width:280px;vertical-align:top}
.gcard img{border-radius:50%;width:56px;height:56px}
.gcard h3{margin:10px 0 4px;font-size:16px}
.gcard a{display:inline-block;margin-top:8px;background:var(--acc);color:#06202f;font-weight:700;padding:8px 14px;border-radius:8px;text-decoration:none}
.hint{color:var(--mut);font-size:12px;margin-top:6px}
code{background:#0b1220;padding:2px 6px;border-radius:6px}
"""

BASE = """<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SecurityBot - Panel</title><style>{{ css }}</style></head>
<body>
<header>
  <h1>&#128737; SecurityBot &mdash; Panel de administraci&oacute;n</h1>
  <nav>
    {% if session.get('panel_login') %}
      <a href="{{ url_for('index') }}">Servidores</a>
      <form method="post" action="{{ url_for('logout') }}" style="display:inline">
        <button class="logout" type="submit">Cerrar sesi&oacute;n</button>
      </form>
    {% endif %}
  </nav>
</header>
<main>
  {% with msgs = get_flashed_messages(with_categories=true) %}
    {% for cat, m in msgs %}
      <div class="flash {{ 'err' if cat=='err' else '' }}">{{ m }}</div>
    {% endfor %}
  {% endwith %}
  {{ content|safe }}
</main>
</body></html>"""

LOGIN_FORM = """
<div class="card" style="max-width:420px;margin:60px auto">
  <h2>&#128274; Iniciar sesi&oacute;n</h2>
  <form method="post" action="{{ url_for('login') }}">
    <label>Contrase&ntilde;a del panel (config.json &rarr; panel_password)</label>
    <input type="password" name="password" autofocus required>
    <button class="send" type="submit">Entrar</button>
  </form>
  <p class="hint">El panel solo responde en {{ host }}:{{ port }} (config.json).</p>
</div>
"""

DASH_CONTENT = """
<h2 style="margin-top:0">Servidores conectados ({{ guilds|length }})</h2>
{% if not guilds %}<div class="card">El bot todav&iacute;a no est&aacute; en ning&uacute;n servidor, o sigue conectando&hellip;</div>{% endif %}
{% for g in guilds %}
  <div class="gcard">
    {% if g.icon %}<img src="{{ g.icon.url }}">{% else %}<img src="https://cdn.discordapp.com/embed/avatars/0.png">{% endif %}
    <h3>{{ g.name }}</h3>
    <div class="hint">&#128101; {{ g.member_count }} miembros &middot; ID: <code>{{ g.id }}</code></div>
    <a href="{{ url_for('guild_page', gid=g.id) }}">Abrir &rarr;</a>
  </div>
{% endfor %}
"""

GUILD_CONTENT = """
<div class="card">
  <h2>{{ g.name }} <span class="hint">&middot; {{ g.member_count }} miembros</span></h2>
  <a href="{{ url_for('index') }}">&larr; Volver a los servidores</a>
</div>

<div class="row">
<div class="card">
  <h2>&#128226; Enviar mensaje a un canal</h2>
  <form method="post" action="{{ url_for('send_channel', gid=g.id) }}">
    <label>Canal</label>
    <select name="channel_id" required>
      {% for c in channels %}<option value="{{ c.id }}"># {{ c.name }}</option>{% endfor %}
    </select>
    <label>Contenido del mensaje</label>
    <textarea name="content" maxlength="2000" placeholder="Escribe el mensaje&hellip;"></textarea>
    <label><input type="checkbox" name="use_embed" style="width:auto"> Enviar como embed (mensaje elegante)</label>
    <div class="row">
      <div><label>T&iacute;tulo del embed (opcional)</label><input type="text" name="title" maxlength="256"></div>
      <div><label>Color</label>
        <select name="color">
          {% for name in colors %}<option value="{{ name }}">{{ name }}</option>{% endfor %}
        </select></div>
    </div>
    <button class="send" type="submit">Enviar al canal</button>
  </form>
</div>

<div class="card">
  <h2>&#9993;&#65039; Enviar mensaje privado (MD) a un usuario</h2>
  <form method="post" action="{{ url_for('send_dm', gid=g.id) }}">
    <label>Usuario (ID num&eacute;rico o nombre)</label>
    <input type="text" name="user" placeholder="Ej: 123456789012345678 o el nombre" required>
    <label>Contenido del mensaje</label>
    <textarea name="content" maxlength="2000" placeholder="Escribe el mensaje privado&hellip;"></textarea>
    <button class="send" type="submit">Enviar MD</button>
  </form>
  <p class="hint">Si el usuario tiene los MD cerrados no se podr&aacute; entregar.</p>
</div>
</div>

<div class="card">
  <h2>&#128227; Anuncio por MD a un rol completo</h2>
  <form method="post" action="{{ url_for('broadcast', gid=g.id) }}">
    <div class="row">
      <div><label>Rol destinatario</label>
        <select name="role_id" required>
          {% for r in roles %}<option value="{{ r.id }}">@ {{ r.name }}</option>{% endfor %}
        </select>
      </div>
      <div><label>Confirmaci&oacute;n de seguridad</label>
        <label style="color:#fbbf24"><input type="checkbox" name="confirm" style="width:auto" required>
        Entiendo que se enviar&aacute; un MD a cada miembro del rol (m&aacute;x. {{ max_bc }})</label>
      </div>
    </div>
    <label>Contenido del anuncio</label>
    <textarea name="content" maxlength="2000" required></textarea>
    <button class="send danger" type="submit">Enviar anuncio</button>
  </form>
</div>

<div class="card">
  <h2>&#128101; Miembros (primeros {{ members|length }})</h2>
  <table>
    <tr><th>Nombre</th><th>ID (c&oacute;pialo para el MD)</th></tr>
    {% for m in members %}
      <tr><td>{{ m.display_name }} <span class="hint">({{ m.name }})</span></td><td><code>{{ m.id }}</code></td></tr>
    {% endfor %}
  </table>
</div>
"""


# -------------------------------------------------------------------- rutas
@app.route("/login", methods=["GET", "POST"])
def login():
    if _logged():
        return redirect(url_for("index"))
    if request.method == "POST":
        ip = request.remote_addr or "?"
        if _login_blocked(ip):
            flash("Demasiados intentos fallidos. Espera 10 minutos.", "err")
        else:
            pw = request.form.get("password", "")
            if pw == str(BOT.config.get("panel_password", "")):
                session["panel_login"] = True
                session.permanent = True
                return redirect(url_for("index"))
            _register_fail(ip)
            flash("Contraseña incorrecta.", "err")
    return _page(LOGIN_FORM)


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
def index():
    g = _guard()
    if g:
        return g
    guilds = sorted(BOT.guilds, key=lambda x: x.name.lower())
    return _page(DASH_CONTENT, guilds=guilds)


@app.route("/g/<int:gid>")
def guild_page(gid):
    g = _guard()
    if g:
        return g
    guild = BOT.get_guild(gid)
    if guild is None:
        flash("Servidor no encontrado.", "err")
        return redirect(url_for("index"))
    channels = sorted(
        [c for c in guild.text_channels if c.permissions_for(guild.me).send_messages],
        key=lambda c: c.position,
    )
    roles = sorted([r for r in guild.roles if not r.is_default() and r.members],
                   key=lambda r: -r.position)
    members = sorted(guild.members, key=lambda m: m.display_name.lower())[:250]
    return _page(GUILD_CONTENT, g=guild, channels=channels, roles=roles,
                 members=members, colors=list(COLORS.keys()), max_bc=MAX_BROADCAST)


@app.route("/g/<int:gid>/send", methods=["POST"])
def send_channel(gid):
    g = _guard()
    if g:
        return g
    if _rate_limited():
        flash("Demasiados envíos por minuto. Espera un momento.", "err")
        return redirect(url_for("guild_page", gid=gid))
    guild = BOT.get_guild(gid)
    if guild is None:
        flash("Servidor no encontrado.", "err")
        return redirect(url_for("index"))
    try:
        channel = guild.get_channel(int(request.form["channel_id"]))
    except (KeyError, ValueError):
        channel = None
    if channel is None:
        flash("Canal no encontrado.", "err")
        return redirect(url_for("guild_page", gid=gid))

    content = request.form.get("content", "").strip()[:MAX_MSG_LEN]
    use_embed = request.form.get("use_embed") == "on"
    title = request.form.get("title", "").strip()[:256]
    color_name = request.form.get("color", "azul")
    kwargs = {}
    if use_embed:
        embed = discord.Embed(description=content or None, color=COLORS.get(color_name, 0x3498DB))
        if title:
            embed.title = title
        kwargs["embed"] = embed
    else:
        if not content:
            flash("Escribe un mensaje.", "err")
            return redirect(url_for("guild_page", gid=gid))
        kwargs["content"] = content
    try:
        BOT.bridge.run_coro(channel.send(**kwargs))
        flash(f"✅ Mensaje enviado a #{channel.name}.")
    except Exception as e:
        flash(f"❌ No se pudo enviar: {e}", "err")
    return redirect(url_for("guild_page", gid=gid))


@app.route("/g/<int:gid>/dm", methods=["POST"])
def send_dm(gid):
    g = _guard()
    if g:
        return g
    if _rate_limited():
        flash("Demasiados envíos por minuto. Espera un momento.", "err")
        return redirect(url_for("guild_page", gid=gid))
    guild = BOT.get_guild(gid)
    if guild is None:
        flash("Servidor no encontrado.", "err")
        return redirect(url_for("index"))
    query = request.form.get("user", "").strip()
    content = request.form.get("content", "").strip()[:MAX_MSG_LEN]
    if not query or not content:
        flash("Falta el usuario o el mensaje.", "err")
        return redirect(url_for("guild_page", gid=gid))

    member = None
    if query.isdigit():
        member = guild.get_member(int(query))
    if member is None:
        q = query.lower()
        member = next((m for m in guild.members
                       if m.name.lower() == q or m.display_name.lower() == q), None)
        if member is None:
            member = next((m for m in guild.members
                           if q in m.name.lower() or q in m.display_name.lower()), None)
    if member is None:
        flash(f"No encontré al usuario «{query}» en este servidor.", "err")
        return redirect(url_for("guild_page", gid=gid))
    if member.bot:
        flash("No puedes enviar MD a otros bots.", "err")
        return redirect(url_for("guild_page", gid=gid))
    try:
        BOT.bridge.run_coro(member.send(content))
        flash(f"✅ MD enviado a {member.display_name}.")
    except discord.Forbidden:
        flash(f"❌ {member.display_name} tiene los MD cerrados o me bloqueó.", "err")
    except Exception as e:
        flash(f"❌ No se pudo enviar: {e}", "err")
    return redirect(url_for("guild_page", gid=gid))


@app.route("/g/<int:gid>/broadcast", methods=["POST"])
def broadcast(gid):
    g = _guard()
    if g:
        return g
    guild = BOT.get_guild(gid)
    if guild is None:
        flash("Servidor no encontrado.", "err")
        return redirect(url_for("index"))
    if request.form.get("confirm") != "on":
        flash("Debes marcar la confirmación de seguridad.", "err")
        return redirect(url_for("guild_page", gid=gid))
    content = request.form.get("content", "").strip()[:MAX_MSG_LEN]
    if not content:
        flash("Escribe el anuncio.", "err")
        return redirect(url_for("guild_page", gid=gid))
    try:
        role = guild.get_role(int(request.form["role_id"]))
    except (KeyError, ValueError):
        role = None
    if role is None:
        flash("Rol no encontrado.", "err")
        return redirect(url_for("guild_page", gid=gid))

    targets = [m for m in role.members if not m.bot][:MAX_BROADCAST]
    if not targets:
        flash("Ese rol no tiene miembros humanos.", "err")
        return redirect(url_for("guild_page", gid=gid))
    okc = failc = 0
    for m in targets:
        try:
            BOT.bridge.run_coro(m.send(f"📢 {guild.name}\n\n{content}"), timeout=30)
            okc += 1
        except Exception:
            failc += 1
        time.sleep(1.0)  # respeto el rate limit de Discord
    flash(f"📣 Anuncio enviado: {okc} entregados, {failc} fallidos (de {len(targets)}).")
    return redirect(url_for("guild_page", gid=gid))
