"""Base de datos SQLite para el sistema de advertencias."""
import sqlite3
import threading
from datetime import datetime, timezone

DB_PATH = "database.sqlite3"
_lock = threading.Lock()


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """CREATE TABLE IF NOT EXISTS warns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            moderator_id INTEGER NOT NULL,
            reason TEXT,
            created_at TEXT NOT NULL
        )"""
    )
    conn.commit()
    return conn


def add_warn(guild_id, user_id, moderator_id, reason):
    with _lock:
        conn = _connect()
        conn.execute(
            "INSERT INTO warns (guild_id, user_id, moderator_id, reason, created_at) VALUES (?,?,?,?,?)",
            (guild_id, user_id, moderator_id, reason, datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()
        conn.close()


def get_warns(guild_id, user_id):
    with _lock:
        conn = _connect()
        cur = conn.execute(
            "SELECT id, moderator_id, reason, created_at FROM warns "
            "WHERE guild_id=? AND user_id=? ORDER BY id",
            (guild_id, user_id),
        )
        rows = cur.fetchall()
        conn.close()
        return rows


def remove_warn(guild_id, warn_id):
    with _lock:
        conn = _connect()
        cur = conn.execute("DELETE FROM warns WHERE guild_id=? AND id=?", (guild_id, warn_id))
        conn.commit()
        conn.close()
        return cur.rowcount > 0
