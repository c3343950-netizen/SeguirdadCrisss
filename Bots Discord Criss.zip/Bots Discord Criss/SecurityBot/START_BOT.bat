@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "venv\Scripts\python.exe" (set PY=venv\Scripts\python.exe) else (set PY=python)
echo ============================================
echo   SecurityBot - Iniciando bot + panel web
echo   Panel: http://127.0.0.1:5000
echo   (Ctrl+C para detener)
echo ============================================
%PY% bot.py
pause
