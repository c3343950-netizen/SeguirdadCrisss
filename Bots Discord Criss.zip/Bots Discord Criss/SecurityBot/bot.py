"""
SecurityBot — Bot de seguridad para Discord + Panel web de administración.

Uso:
    1) Edita config.json y pon el token de tu bot.
    2) Ejecuta:  python bot.py   (o START_BOT.bat)
    3) Panel web: http://127.0.0.1:5000  (clave en config.json → panel_password)
"""
import asyncio
import logging
import sys
import threading

try:
    import discord
    from discord import app_commands
    from discord.ext import commands
except ImportError:
    print("=" * 64)
    print(" FALTA EL MODULO discord.py en este interprete de Python")
    print(" Solucion 1: ejecuta INSTALL.bat dentro de esta carpeta")
    print(" Solucion 2: arranca siempre con START_BOT.bat")
    print(" Solucion 3 (VS Code): selecciona el interprete")
    print("   SecurityBot\\venv\\Scripts\\python.exe")
    print("   (Ctrl+Shift+P -> Python: Select Interpreter)")
    print("=" * 64)
    sys.exit(1)

import panel
from settings import load as load_config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("SecurityBot")


class Bridge:
    """Comunica el panel web (hilo aparte) con el bot (bucle asyncio)."""

    def __init__(self, bot):
        self.bot = bot
        self.loop = None

    def run_coro(self, coro, timeout=45):
        if self.loop is None:
            raise RuntimeError("El bot todavía no está conectado.")
        fut = asyncio.run_coroutine_threadsafe(coro, self.loop)
        return fut.result(timeout)


class SecurityBot(commands.Bot):
    def __init__(self, config):
        self.config = config
        intents = discord.Intents.default()
        intents.members = True          # requerido: SERVER MEMBERS INTENT
        intents.message_content = True  # requerido: MESSAGE CONTENT INTENT
        intents.moderation = True
        intents.webhooks = True
        super().__init__(
            command_prefix=config.get("prefix", "!"),
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions(
                everyone=False, roles=False, users=True
            ),
        )
        self.bridge = Bridge(self)
        self._synced_guilds = set()

    async def setup_hook(self):
        # El panel vive en otro hilo: necesita el bucle asyncio del bot
        # para enviarle órdenes (asyncio.run_coroutine_threadsafe).
        self.bridge.loop = asyncio.get_running_loop()
        log.info("Puente panel<->bot listo")
        for ext in ("cogs.security", "cogs.moderation", "cogs.logs"):
            await self.load_extension(ext)
        from cogs.security import VerifyView
        self.add_view(VerifyView(self))  # vista persistente del botón /verify
        try:
            cmds = await self.tree.sync()
            log.info("Comandos globales sincronizados: %d", len(cmds))
        except Exception:
            log.exception("No se pudieron sincronizar los comandos globales")
        # El panel arranca en un hilo separado y comparte el mismo bot.
        threading.Thread(
            target=panel.run_panel, args=(self,), daemon=True, name="panel-web"
        ).start()

    async def on_ready(self):
        log.info(
            "Conectado como %s (id=%s) — %d servidor(es)",
            self.user, self.user.id, len(self.guilds),
        )
        # Sincroniza los comandos por servidor para que aparezcan al instante.
        for guild in list(self.guilds):
            if guild.id in self._synced_guilds:
                continue
            try:
                self.tree.copy_global_to(guild=guild)
                await self.tree.sync(guild=guild)
                self._synced_guilds.add(guild.id)
            except Exception:
                log.exception("No se pudo sincronizar en %s", guild.name)
        log.info(
            "Panel web: http://%s:%s",
            self.config.get("panel_host", "127.0.0.1"),
            self.config.get("panel_port", 5000),
        )


def main():
    cfg = load_config()
    token = (cfg.get("token") or "").strip()
    if not token or "PON_AQUI" in token:
        print("=" * 64)
        print(" FALTA EL TOKEN")
        print(" 1) Abre config.json")
        print(' 2) Pega el token de tu bot en la linea "token"')
        print(" 3) Vuelve a ejecutar este programa")
        print(" Guia completa en README.txt")
        print("=" * 64)
        sys.exit(1)

    bot = SecurityBot(cfg)

    @bot.tree.error
    async def on_app_command_error(interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            msg = "No tienes permisos para usar este comando."
        elif isinstance(error, app_commands.BotMissingPermissions):
            msg = "Me faltan permisos: " + ", ".join(
                getattr(error, "missing_permissions", [])
            )
        elif isinstance(error, app_commands.CheckFailure):
            msg = "No puedes usar este comando aquí."
        else:
            log.error("Error en comando: %r", error)
            msg = "Ocurrió un error inesperado. Revisa la consola."
        try:
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)
        except Exception:
            pass

    try:
        bot.run(token)
    except discord.LoginFailure:
        print("TOKEN INVÁLIDO. Vuelve a copiarlo del portal de desarrolladores.")
        sys.exit(1)


if __name__ == "__main__":
    main()
