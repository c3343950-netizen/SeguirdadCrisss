==========================================================
 SecurityBot — Bot de seguridad para Discord + Panel web
==========================================================

QUÉ INCLUYE
-----------
- Anti-spam, anti-invite, anti-link, anti-palabras prohibidas
- Anti-mención masiva (@everyone spam)
- Anti-raid: detecta entradas masivas y expulsa automáticamente
- Anti-nuke: detecta borrados/creaciones masivas de canales, roles,
  baneos y kicks usando los audit logs, y castiga al responsable
- Logs: mensajes borrados/editados, entradas/salidas
- Bienvenida configurable + sistema de verificación con botón
- Moderación: /ban /kick /timeout /clear /warn /warnings /lock
  /unlock /lockdown /slowmode /serverinfo /userinfo /trust y más
- PANEL WEB para administradores:
  * Enviar mensajes a un canal específico
  * Enviar mensajes privados (MD) a un usuario específico
  * Anuncio por MD a todos los miembros de un rol

==========================================================
PASO 1 — Crear el bot en Discord (solo una vez)
==========================================================
1. Entra a https://discord.com/developers/applications
2. "New Application" -> ponle nombre -> Create
3. Pestaña "Bot" -> botón "Reset Token" -> COPIA el token
   (no lo compartas con nadie)
4. En esa misma pestaña, activa:
     - SERVER MEMBERS INTENT  (obligatorio)
     - MESSAGE CONTENT INTENT (obligatorio)
   y pulsa "Save Changes".
5. Pestaña "OAuth2" -> "URL Generator":
     - Marca scopes: bot y applications.commands
     - En "Bot Permissions" marca: Administrador
   Copia la URL generada, ábrela e invita el bot a tu servidor.

==========================================================
PASO 2 — Configurar
==========================================================
1. Abre el archivo config.json con el Bloc de notas.
2. Pega tu token en la línea "token".
3. CAMBIA la clave del panel: "panel_password" (elige una segura).
4. Opcional: edita bad_words, whitelist_links, umbrales, etc.
5. Guarda el archivo.

==========================================================
PASO 3 — Instalar y arrancar
==========================================================
1. Doble clic en INSTALL.bat   (solo la primera vez)
2. Doble clic en START_BOT.bat (cada vez que quieras encenderlo)
3. Verás en la consola:
     "Conectado como TuBot#1234"
     "[PANEL] Panel web listo -> http://127.0.0.1:5000"

==========================================================
PASO 4 — Usar el panel
==========================================================
1. Abre http://127.0.0.1:5000 en tu navegador (mientras el bot corre).
2. Inicia sesión con la clave que pusiste en panel_password.
3. Elige el servidor -> verás:
     - "Enviar mensaje a un canal": elige canal, escribe el mensaje,
       marca "embed" si quieres un mensaje elegante con color.
     - "Enviar MD a un usuario": pon el ID del usuario (la lista de
       miembros de abajo te muestra los IDs) o su nombre, y el texto.
     - "Anuncio por MD a un rol": envía un MD a todos los miembros
       con ese rol (máximo 200, con confirmación de seguridad).

==========================================================
PASO 5 — Configurar seguridad en el servidor (comandos /)
==========================================================
En Discord escribe estos comandos:
  /setlogs      -> canal donde llegan las alertas de seguridad
  /setwelcome   -> canal de bienvenidas
  /setverify    -> rol que se da al verificarse
  /setupverify  -> publica el mensaje con botón "Verificarme"
  /trust        -> protege a un admin del anti-nuke
  /lockdown     -> bloquea/desbloquea TODOS los canales (emergencia)
  /raidmode     -> activa el modo raid manualmente (on/off)

Importante: mueve el ROL del bot por ENCIMA de los roles de los
miembros (Configuración del servidor -> Roles) para que pueda
silenciar, expulsar y asignar el rol de verificado.

==========================================================
AJUSTES DE PROTECCIÓN (config.json -> "protections")
==========================================================
- anti_invite: borra invites de otros servidores
- anti_link: borra enlaces (off por defecto); whitelist_links permite
  los tuyos
- bad_words: lista de palabras prohibidas, ej: ["mala1", "mala2"]
- anti_spam: max_messages en interval_seconds -> timeout 10 min
- anti_mention: máximo de menciones por mensaje
- anti_massjoin: max_joins en interval_seconds -> RAID:
    raid_action: "kick" (expulsa nuevos) o "alert" (solo alerta)
    raid_duration_minutes: cuánto dura el modo raid
- anti_nuke: max_actions en interval_seconds (borrar canales/roles,
  banear, kickear) -> castiga con "action": timeout / ban / strip
- punishment: "timeout" o "delete_only"

==========================================================
ACCEDER AL PANEL DESDE OTRO PC (opcional)
==========================================================
1. En config.json cambia "panel_host" a "0.0.0.0".
2. Abre el puerto 5000 en el firewall de Windows.
3. Entra con la IP de este PC: http://IP-DEL-PC:5000
   ¡Cambia la contraseña del panel antes de hacer esto!

==========================================================
PROBLEMAS COMUNES
==========================================================
- "TOKEN INVÁLIDO": copia el token otra vez del portal de devs.
- El bot no responde /commands: espera 1-2 min tras encenderlo o
  vuelve a invitarlo con el scope applications.commands.
- No puede silenciar/dar roles: sube el rol del bot por encima de
  los demás en Configuración del servidor -> Roles.
- No llegan logs: usa /setlogs para elegir el canal.
- El MD no llega: el usuario tiene los MD cerrados.
==========================================================
