"""Comandos de moderación (barra /) para el staff del servidor."""
import asyncio
import random
import string
from datetime import timedelta
from typing import Literal

import discord
from discord import app_commands
from discord.ext import commands

import database
from settings import guild_conf, save_config


def _ok(title, description, color=discord.Color.green()):
    return discord.Embed(title=title, description=description, color=color)


def _err(description):
    return discord.Embed(title="❌ Error", description=description, color=discord.Color.red())


class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _check_target(self, interaction, member) -> str | None:
        """Devuelve un mensaje de error o None si se puede actuar."""
        me = interaction.guild.me
        author = interaction.user
        if member.id == self.bot.user.id:
            return "No puedo actuar sobre mí mismo."
        if member.id == interaction.guild.owner_id:
            return "No puedo actuar sobre el dueño del servidor."
        if member.top_role >= me.top_role:
            return "Mi rol está por debajo del de ese usuario. Mueve mi rol más arriba."
        if author.id != interaction.guild.owner_id and member.top_role >= author.top_role:
            return "Ese usuario tiene un rol igual o superior al tuyo."
        return None

    # ------------------------------------------------------------------ ban
    @app_commands.command(description="Banea a un usuario del servidor.")
    @app_commands.default_permissions(ban_members=True)
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.describe(usuario="Usuario a banear", razon="Motivo del baneo",
                           borrar_dias="Borrar mensajes de los últimos X días (0-7)")
    async def ban(self, interaction, usuario: discord.Member,
                  razon: str = "Sin motivo", borrar_dias: app_commands.Range[int, 0, 7] = 0):
        err = await self._check_target(interaction, usuario)
        if err:
            await interaction.response.send_message(embed=_err(err), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        try:
            await usuario.send(
                f"Fuiste baneado de **{interaction.guild.name}**.\nMotivo: {razon}"
            )
        except (discord.Forbidden, discord.HTTPException):
            pass
        await interaction.guild.ban(usuario, reason=f"{razon} — por {interaction.user}",
                                    delete_message_seconds=borrar_dias * 86400)
        await interaction.followup.send(
            embed=_ok("🔨 Usuario baneado",
                      f"**{usuario}** (`{usuario.id}`) fue baneado.\n**Motivo:** {razon}")
        )

    # ----------------------------------------------------------------- kick
    @app_commands.command(description="Expulsa a un usuario del servidor.")
    @app_commands.default_permissions(kick_members=True)
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.describe(usuario="Usuario a expulsar", razon="Motivo")
    async def kick(self, interaction, usuario: discord.Member, razon: str = "Sin motivo"):
        err = await self._check_target(interaction, usuario)
        if err:
            await interaction.response.send_message(embed=_err(err), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        try:
            await usuario.send(
                f"Fuiste expulsado de **{interaction.guild.name}**.\nMotivo: {razon}"
            )
        except (discord.Forbidden, discord.HTTPException):
            pass
        await usuario.kick(reason=f"{razon} — por {interaction.user}")
        await interaction.followup.send(
            embed=_ok("🥾 Usuario expulsado",
                      f"**{usuario}** (`{usuario.id}`) fue expulsado.\n**Motivo:** {razon}")
        )

    # -------------------------------------------------------------- timeout
    @app_commands.command(description="Silencia (timeout) a un usuario X minutos.")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.describe(usuario="Usuario a silenciar", minutos="Duración en minutos (máx. 40320 = 28 días)",
                           razon="Motivo")
    async def timeout(self, interaction, usuario: discord.Member,
                      minutos: app_commands.Range[int, 1, 40320], razon: str = "Sin motivo"):
        err = await self._check_target(interaction, usuario)
        if err:
            await interaction.response.send_message(embed=_err(err), ephemeral=True)
            return
        await usuario.timeout(timedelta(minutes=minutos), reason=f"{razon} — por {interaction.user}")
        await interaction.response.send_message(
            embed=_ok("🔇 Usuario silenciado",
                      f"**{usuario.mention}** silenciado **{minutos} min**.\n**Motivo:** {razon}")
        )

    @app_commands.command(description="Quita el timeout a un usuario.")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def untimeout(self, interaction, usuario: discord.Member):
        await usuario.timeout(None, reason=f"Timeout quitado por {interaction.user}")
        await interaction.response.send_message(
            embed=_ok("🔊 Timeout quitado", f"A **{usuario.mention}** se le quitó el silencio.")
        )

    # ---------------------------------------------------------------- clear
    @app_commands.command(description="Borra mensajes de un canal (hasta 500).")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    @app_commands.describe(cantidad="Cuántos mensajes borrar (1-500)",
                           usuario="Solo mensajes de este usuario (opcional)")
    async def clear(self, interaction, cantidad: app_commands.Range[int, 1, 500],
                    usuario: discord.Member | None = None):
        await interaction.response.defer(ephemeral=True)

        def check(m):
            return usuario is None or m.author.id == usuario.id

        borrados = await interaction.channel.purge(limit=cantidad, check=check, bulk=True)
        await interaction.followup.send(
            embed=_ok("🧹 Mensajes borrados",
                      f"Se borraron **{len(borrados)}** mensajes"
                      + (f" de **{usuario}**." if usuario else ".")),
            ephemeral=True,
        )

    # ----------------------------------------------------------------- warns
    @app_commands.command(description="Advierte a un usuario (se guarda en la base de datos).")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.describe(usuario="Usuario a advertir", razon="Motivo de la advertencia")
    async def warn(self, interaction, usuario: discord.Member, razon: str):
        if usuario.bot:
            await interaction.response.send_message(embed=_err("No puedes advertir a un bot."), ephemeral=True)
            return
        database.add_warn(interaction.guild_id, usuario.id, interaction.user.id, razon)
        total = len(database.get_warns(interaction.guild_id, usuario.id))
        try:
            await usuario.send(
                f"⚠ Recibiste una advertencia en **{interaction.guild.name}** ({total} en total).\n"
                f"Motivo: {razon}"
            )
        except (discord.Forbidden, discord.HTTPException):
            pass
        await interaction.response.send_message(
            embed=_ok("⚠ Usuario advertido",
                      f"**{usuario.mention}** ahora tiene **{total}** advertencia(s).\n**Motivo:** {razon}")
        )

    @app_commands.command(description="Muestra las advertencias de un usuario.")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warnings(self, interaction, usuario: discord.Member):
        rows = database.get_warns(interaction.guild_id, usuario.id)
        if not rows:
            await interaction.response.send_message(
                embed=_ok("📋 Advertencias", f"**{usuario.mention}** no tiene advertencias. ✅")
            )
            return
        lines = [f"• `#{wid}` — {reason} — por <@{mod}> — {created[:10]}"
                 for wid, mod, reason, created in rows]
        e = _ok("📋 Advertencias", f"**{usuario.mention}** tiene {len(rows)} advertencia(s):\n" + "\n".join(lines[:25]))
        await interaction.response.send_message(embed=e)

    @app_commands.command(description="Elimina una advertencia por su número (#id).")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def delwarn(self, interaction, usuario: discord.Member, id_advertencia: int):
        ok = database.remove_warn(interaction.guild_id, id_advertencia)
        if ok:
            await interaction.response.send_message(
                embed=_ok("🗑 Advertencia eliminada", f"Se eliminó la advertencia `#{id_advertencia}` de {usuario.mention}.")
            )
        else:
            await interaction.response.send_message(
                embed=_err(f"No existe esa advertencia para {usuario.mention}."), ephemeral=True
            )

    # -------------------------------------------------------- lock / unlock
    @app_commands.command(description="Bloquea un canal (nadie puede escribir salvo el staff).")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def lock(self, interaction, canal: discord.TextChannel | None = None):
        canal = canal or interaction.channel
        ow = canal.overwrites_for(interaction.guild.default_role)
        ow.send_messages = False
        await canal.set_overwrites(interaction.guild.default_role, ow,
                                   reason=f"Canal bloqueado por {interaction.user}")
        await interaction.response.send_message(embed=_ok("🔒 Canal bloqueado", f"{canal.mention} quedó bloqueado."))

    @app_commands.command(description="Desbloquea un canal bloqueado con /lock.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def unlock(self, interaction, canal: discord.TextChannel | None = None):
        canal = canal or interaction.channel
        ow = canal.overwrites_for(interaction.guild.default_role)
        ow.send_messages = None
        await canal.set_overwrites(interaction.guild.default_role, ow,
                                   reason=f"Canal desbloqueado por {interaction.user}")
        await interaction.response.send_message(embed=_ok("🔓 Canal desbloqueado", f"{canal.mention} volvió a la normalidad."))

    @app_commands.command(description="Bloquea/desbloquea TODOS los canales de texto (modo lockdown).")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(modo="on = bloquear todo, off = desbloquear todo")
    async def lockdown(self, interaction, modo: Literal["on", "off"]):
        await interaction.response.defer()
        guild = interaction.guild
        bloqueados, fallos = 0, 0
        for canal in list(guild.text_channels)[:200]:
            try:
                ow = canal.overwrites_for(guild.default_role)
                ow.send_messages = False if modo == "on" else None
                await canal.set_overwrites(guild.default_role, ow, reason=f"Lockdown {modo} por {interaction.user}")
                bloqueados += 1
            except (discord.Forbidden, discord.HTTPException):
                fallos += 1
            await asyncio.sleep(0.3)
        await interaction.followup.send(
            embed=_ok("🔒 Lockdown",
                      f"Modo **{modo}** aplicado a **{bloqueados}** canales."
                      + (f" ({fallos} fallaron por permisos)" if fallos else ""))
        )

    # ------------------------------------------------------------- slowmode
    @app_commands.command(description="Pone modo lento a un canal (0 = quitar).")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.describe(canal="Canal", segundos="Segundos de espera entre mensajes (0-21600)")
    async def slowmode(self, interaction, canal: discord.TextChannel,
                       segundos: app_commands.Range[int, 0, 21600]):
        await canal.edit(slowmode_delay=segundos, reason=f"Por {interaction.user}")
        txt = f"**{segundos}s** de modo lento" if segundos else "Modo lento **quitado**"
        await interaction.response.send_message(embed=_ok("🐢 Slowmode", f"{canal.mention}: {txt}."))

    # ------------------------------------------------------- configuración
    @app_commands.command(description="Define el canal donde van los logs de seguridad.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def setlogs(self, interaction, canal: discord.TextChannel):
        cfg = guild_conf(self.bot.config, interaction.guild_id)
        cfg["logs_channel_id"] = canal.id
        save_config(self.bot.config)
        await interaction.response.send_message(embed=_ok("🧾 Logs configurados", f"Canal de logs: {canal.mention}."))

    @app_commands.command(description="Define el canal de bienvenida.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def setwelcome(self, interaction, canal: discord.TextChannel):
        cfg = guild_conf(self.bot.config, interaction.guild_id)
        cfg["welcome_channel_id"] = canal.id
        save_config(self.bot.config)
        await interaction.response.send_message(embed=_ok("👋 Bienvenida configurada", f"Canal de bienvenida: {canal.mention}."))

    @app_commands.command(description="Define el rol que se da al verificarse.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def setverify(self, interaction, rol: discord.Role):
        cfg = guild_conf(self.bot.config, interaction.guild_id)
        cfg["verify_role_id"] = rol.id
        save_config(self.bot.config)
        await interaction.response.send_message(embed=_ok("✅ Verificación configurada", f"Rol de verificado: {rol.mention}."))

    @app_commands.command(description="Publica el mensaje con el botón de verificación.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(canal="Canal donde se publica la verificación")
    async def setupverify(self, interaction, canal: discord.TextChannel):
        from cogs.security import VerifyView
        e = discord.Embed(
            title="🛡 Verificación",
            description="Pulsa el botón de abajo para demostrar que no eres un bot y acceder al servidor.",
            color=discord.Color.blurple(),
        )
        await canal.send(embed=e, view=VerifyView(self.bot))
        await interaction.response.send_message(embed=_ok("✅ Verificación publicada", f"Publicado en {canal.mention}."), ephemeral=True)

    @app_commands.command(description="Protege a un usuario del anti-nuke (no lo castiga jamás).")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def trust(self, interaction, usuario: discord.User):
        cfg = guild_conf(self.bot.config, interaction.guild_id)
        lista = cfg.setdefault("trusted_ids", [])
        if usuario.id in lista:
            lista.remove(usuario.id)
            msg = f"{usuario.mention} **ya no** está protegido del anti-nuke."
        else:
            lista.append(usuario.id)
            msg = f"{usuario.mention} ahora está **protegido** del anti-nuke."
        save_config(self.bot.config)
        await interaction.response.send_message(embed=_ok("🤝 Trust list", msg))

    @app_commands.command(description="Genera un código temporal para verificar un canal (utilidad anti-raid).")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def codetemp(self, interaction):
        code = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        await interaction.response.send_message(
            embed=_ok("🔑 Código temporal", f"Tu código: `{code}`\n(cópialo antes de cerrar este mensaje)"),
            ephemeral=True,
        )

    # ------------------------------------------------------------ info
    @app_commands.command(description="Información del servidor.")
    async def serverinfo(self, interaction):
        g = interaction.guild
        e = discord.Embed(title=f"ℹ {g.name}", color=discord.Color.blurple())
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        e.add_field(name="Miembros", value=g.member_count)
        e.add_field(name="Canales", value=len(g.channels))
        e.add_field(name="Roles", value=len(g.roles))
        e.add_field(name="Dueño", value=f"<@{g.owner_id}>")
        e.add_field(name="Creado", value=g.created_at.strftime("%d/%m/%Y"))
        e.add_field(name="Nivel de verificación", value=str(g.verification_level).title())
        await interaction.response.send_message(embed=e)

    @app_commands.command(description="Información de un usuario.")
    async def userinfo(self, interaction, usuario: discord.Member | None = None):
        usuario = usuario or interaction.user
        roles = [r.mention for r in reversed(usuario.roles[1:])][:15] or ["(sin roles)"]
        e = discord.Embed(title=f"👤 {usuario}", color=discord.Color.blurple())
        e.set_thumbnail(url=usuario.display_avatar.url)
        e.add_field(name="ID", value=usuario.id)
        e.add_field(name="Cuenta creada", value=usuario.created_at.strftime("%d/%m/%Y"))
        e.add_field(name="Entró al servidor", value=usuario.joined_at.strftime("%d/%m/%Y") if usuario.joined_at else "?")
        e.add_field(name=f"Roles ({len(usuario.roles)-1})", value=" ".join(roles), inline=False)
        warns = database.get_warns(interaction.guild_id, usuario.id)
        e.add_field(name="Advertencias", value=len(warns))
        await interaction.response.send_message(embed=e)

    @app_commands.command(description="Muestra la latencia del bot.")
    async def ping(self, interaction):
        await interaction.response.send_message(
            embed=_ok("🏓 Pong", f"Latencia: **{round(self.bot.latency*1000)} ms**"),
            ephemeral=True,
        )


async def setup(bot):
    await bot.add_cog(Moderation(bot))
