"""Logs de seguridad: mensajes borrados/editados, entradas y salidas."""
import discord
from discord.ext import commands

from settings import guild_conf


class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def logs_channel(self, guild):
        cid = guild_conf(self.bot.config, guild.id).get("logs_channel_id", 0)
        return guild.get_channel(cid) if cid else None

    async def send_log(self, guild, embed):
        ch = self.logs_channel(guild)
        if ch is None:
            return
        try:
            await ch.send(embed=embed)
        except (discord.Forbidden, discord.HTTPException):
            pass

    @commands.Cog.listener()
    async def on_raw_message_delete(self, payload):
        if payload.guild_id is None:
            return
        guild = self.bot.get_guild(payload.guild_id)
        if guild is None:
            return
        ch = self.logs_channel(guild)
        if ch and payload.channel_id == ch.id:
            return  # no registrar borrados dentro del propio canal de logs
        cached = payload.cached_message
        if cached:
            desc = (f"**Autor:** {cached.author.mention} (`{cached.author}`)\n"
                    f"**Canal:** <#{payload.channel_id}>\n"
                    f"**Contenido:** ||{cached.content[:800] or '(vacío)'}||")
        else:
            desc = f"**Canal:** <#{payload.channel_id}>\n(mensaje antiguo, contenido no disponible)"
        e = discord.Embed(title="🗑 Mensaje borrado", description=desc, color=discord.Color.red())
        if cached and cached.author:
            e.set_author(name=str(cached.author), icon_url=cached.author.display_avatar.url)
        await self.send_log(guild, e)

    @commands.Cog.listener()
    async def on_raw_message_edit(self, payload):
        if payload.guild_id is None:
            return
        guild = self.bot.get_guild(payload.guild_id)
        if guild is None:
            return
        data = payload.data or {}
        new_content = data.get("content")
        if not new_content:
            return
        cached = payload.cached_message
        before = cached.content if cached else "(desconocido)"
        if before == new_content:
            return
        author = cached.author if cached else None
        if author:
            autor_line = author.mention
        else:
            aid = (data.get("author") or {}).get("id", "?")
            autor_line = f"`{aid}`"
        e = discord.Embed(
            title="✏ Mensaje editado",
            description=(
                f"**Autor:** {autor_line}\n"
                f"**Canal:** <#{payload.channel_id}>\n"
                f"**Antes:** ||{before[:400]}||\n"
                f"**Después:** ||{new_content[:400]}||"
            ),
            color=discord.Color.yellow(),
        )
        await self.send_log(guild, e)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        e = discord.Embed(
            title="📥 Entrada",
            description=f"{member.mention} (`{member}`) entró al servidor.",
            color=discord.Color.green(),
        )
        e.add_field(name="ID", value=member.id)
        e.add_field(name="Cuenta creada", value=member.created_at.strftime("%d/%m/%Y"))
        dias = (discord.utils.utcnow() - member.created_at).days
        if dias < 7:
            e.set_footer(text="⚠ Cuenta con menos de 7 días — posible cuenta nueva para raid")
        await self.send_log(member.guild, e)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        e = discord.Embed(
            title="📤 Salida",
            description=f"**{member}** (`{member.id}`) salió del servidor.",
            color=discord.Color.dark_grey(),
        )
        await self.send_log(member.guild, e)


async def setup(bot):
    await bot.add_cog(Logs(bot))
