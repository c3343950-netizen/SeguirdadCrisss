"""Protecciones: anti-spam, anti-invite, anti-link, palabras prohibidas,
anti-mención, anti-raid (mass join) y anti-nuke con audit logs."""
import re
import time
from collections import defaultdict, deque
from datetime import timedelta

import discord
from discord.ext import commands

from settings import guild_conf

INVITE_RE = re.compile(
    r"(?:discord\.(?:gg|io|me|li)|discord(?:app)?\.com/invite)/[\w-]+", re.I
)
URL_RE = re.compile(r"https?://\S+", re.I)


class VerifyView(discord.ui.View):
    """Botón de verificación persistente (creado con /setupverify)."""

    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(
        label="✅ Verificarme",
        style=discord.ButtonStyle.success,
        custom_id="securitybot:verify",
    )
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button):
        conf = guild_conf(self.bot.config, interaction.guild_id)
        role_id = conf.get("verify_role_id", 0)
        role = interaction.guild.get_role(role_id) if role_id else None
        if role is None:
            await interaction.response.send_message(
                "El rol de verificación no está configurado. Un admin debe usar `/setverify`.",
                ephemeral=True,
            )
            return
        if role in interaction.user.roles:
            await interaction.response.send_message("Ya estás verificado. ✅", ephemeral=True)
            return
        try:
            await interaction.user.add_roles(role, reason="Verificación (SecurityBot)")
            await interaction.response.send_message(f"✅ Verificado con {role.mention}", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(
                "No pude darte el rol. Mi rol debe estar **encima** del rol de verificación.",
                ephemeral=True,
            )


class Security(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.msg_times = defaultdict(deque)   # (gid, uid) -> timestamps
        self.join_times = defaultdict(deque)  # gid -> timestamps
        self.nuke_times = defaultdict(deque)  # (gid, uid) -> (timestamp, tipo)
        self.recent_timeout = {}              # (gid, uid) -> hasta_cuándo
        self.raid_until = {}                  # gid -> timestamp_monotonic

    # ------------------------------------------------------------------ utils
    def conf(self, guild):
        return guild_conf(self.bot.config, guild.id)

    def get_logs_channel(self, guild):
        cid = self.conf(guild).get("logs_channel_id", 0)
        return guild.get_channel(cid) if cid else None

    async def alert(self, guild, title, description, color=discord.Color.red(), ping=False):
        ch = self.get_logs_channel(guild)
        if ch is None:
            return
        embed = discord.Embed(title=title, description=description, color=color)
        try:
            await ch.send(content="@here" if ping else None, embed=embed)
        except (discord.Forbidden, discord.HTTPException):
            pass

    async def _punish_message(self, message, violation):
        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound):
            pass
        prot = self.bot.config.get("protections", {})
        if prot.get("punishment", "timeout") == "timeout":
            key = (message.guild.id, message.author.id)
            if self.recent_timeout.get(key, 0) < time.monotonic():
                self.recent_timeout[key] = time.monotonic() + 600
                try:
                    await message.author.timeout(
                        timedelta(minutes=10), reason=f"SecurityBot: {violation}"
                    )
                    try:
                        await message.author.send(
                            f"Fuiste silenciado 10 minutos en **{message.guild.name}**.\n"
                            f"Motivo: {violation}"
                        )
                    except (discord.Forbidden, discord.HTTPException):
                        pass
                except (discord.Forbidden, discord.HTTPException):
                    pass
        await self.alert(
            message.guild,
            "🛡 Violación detectada",
            f"**Usuario:** {message.author.mention} (`{message.author}`)\n"
            f"**Canal:** {message.channel.mention}\n"
            f"**Motivo:** {violation}\n"
            f"**Mensaje:** ||{message.content[:500] or '(vacío)'}||",
            color=discord.Color.orange(),
        )

    async def _executor(self, guild, action, target):
        """Encuentra quién hizo la acción usando los audit logs."""
        try:
            target_id = getattr(target, "id", target)
            async for entry in guild.audit_logs(limit=6, action=action):
                if entry.target and getattr(entry.target, "id", None) == target_id:
                    age = (discord.utils.utcnow() - entry.created_at).total_seconds()
                    if age < 15:
                        return entry.user
        except (discord.Forbidden, discord.HTTPException):
            pass
        return None

    async def _nuke_check(self, guild, user, kind, description):
        if guild is None or user is None or user.bot:
            return
        if user.id in (guild.owner_id, self.bot.user.id):
            return
        conf = self.conf(guild)
        if user.id in conf.get("trusted_ids", []):
            return
        prot = self.bot.config.get("protections", {})
        an = prot.get("anti_nuke", {})
        if not an.get("enabled", True):
            return
        key = (guild.id, user.id)
        dq = self.nuke_times[key]
        now = time.monotonic()
        dq.append((now, kind))
        window = an.get("interval_seconds", 30)
        while dq and now - dq[0][0] > window:
            dq.popleft()
        if len(dq) <= an.get("max_actions", 4):
            return
        dq.clear()
        action = an.get("action", "timeout")
        punish_txt = ""
        try:
            member = guild.get_member(user.id)
            if action == "ban" and member:
                await member.ban(reason=f"SecurityBot anti-nuke: {kind}")
                punish_txt = "Baneado automáticamente."
            elif action == "timeout" and member:
                await member.timeout(
                    timedelta(days=28), reason=f"SecurityBot anti-nuke: {kind}"
                )
                punish_txt = "Silenciado 28 días."
            elif action == "strip" and member:
                roles = [r for r in member.roles if r != guild.default_role and r < guild.me.top_role]
                await member.remove_roles(*roles, reason=f"SecurityBot anti-nuke: {kind}")
                punish_txt = "Roles removidos."
        except (discord.Forbidden, discord.HTTPException) as e:
            punish_txt = f"No pude castigarlo ({e}). ¡Revisa mi rol y permisos!"
        await self.alert(
            guild,
            "🚨 ANTI-NUKE activado",
            f"**Sospechoso:** {user.mention} (`{user}`)\n"
            f"**Acción repetida:** {kind} — {description}\n"
            f"**Resultado:** {punish_txt or 'solo alerta'}",
            ping=True,
        )

    # ------------------------------------------------------------- on_message
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.guild is None or message.author.bot:
            return
        member = message.author
        if not isinstance(member, discord.Member):
            return
        if member.guild_permissions.administrator or member.guild_permissions.manage_guild:
            return  # el staff no pasa por los filtros

        prot = self.bot.config.get("protections", {})
        conf = self.conf(message.guild)
        content = message.content or ""
        violation = None

        if prot.get("anti_invite", True) and INVITE_RE.search(content):
            allowed = conf.get("allowed_invites", [])
            if not any(inv.lower() in content.lower() for inv in allowed):
                violation = "Invite de otro servidor (anti-invite)"

        if violation is None and prot.get("anti_link", False):
            if URL_RE.search(content) and not any(
                dom.lower() in content.lower() for dom in prot.get("whitelist_links", [])
            ):
                violation = "Enlace no permitido (anti-link)"

        if violation is None:
            bad = [w for w in prot.get("bad_words", []) if w]
            low = content.lower()
            if any(w.lower() in low for w in bad):
                violation = "Palabra prohibida"

        if violation is None and prot.get("anti_spam", {}).get("enabled", True):
            asp = prot.get("anti_spam", {})
            key = (message.guild.id, member.id)
            dq = self.msg_times[key]
            now = time.monotonic()
            dq.append(now)
            window = asp.get("interval_seconds", 5)
            while dq and now - dq[0] > window:
                dq.popleft()
            if len(dq) > asp.get("max_messages", 5):
                violation = "Flood (anti-spam)"
                dq.clear()

        if violation is None and prot.get("anti_mention", {}).get("enabled", True):
            am = prot.get("anti_mention", {})
            n = len(message.mentions) + len(message.role_mentions)
            everyone_ping = ("@everyone" in content or "@here" in content) and \
                not member.guild_permissions.mention_everyone
            if n > am.get("max_mentions", 5) or everyone_ping:
                violation = "Menciones masivas (anti-mention)"

        if violation:
            await self._punish_message(message, violation)

    # ---------------------------------------------------------- member events
    @commands.Cog.listener()
    async def on_member_join(self, member):
        guild = member.guild
        conf = self.conf(guild)
        prot = self.bot.config.get("protections", {})
        mj = prot.get("anti_massjoin", {})
        now = time.monotonic()

        dq = self.join_times[guild.id]
        dq.append(now)
        window = mj.get("interval_seconds", 20)
        while dq and now - dq[0] > window:
            dq.popleft()

        raid_active = self.raid_until.get(guild.id, 0) > now
        if not raid_active and mj.get("enabled", True) and len(dq) >= mj.get("max_joins", 6):
            dur = prot.get("raid_duration_minutes", 10)
            self.raid_until[guild.id] = now + dur * 60
            raid_active = True
            await self.alert(
                guild,
                "🚨 POSIBLE RAID DETECTADO",
                f"**{len(dq)} usuarios entraron en {window}s.**\n"
                f"Modo raid activado por {dur} minutos. "
                f"Acción automática: **{prot.get('raid_action', 'kick')}**.",
                ping=True,
            )

        if raid_active and prot.get("raid_action", "kick") == "kick":
            try:
                await member.kick(reason="SecurityBot: modo raid activo (anti-mass-join)")
                await self.alert(
                    guild, "🥾 Expulsado por raid",
                    f"{member.mention} (`{member}`) fue expulsado automáticamente.",
                )
            except (discord.Forbidden, discord.HTTPException):
                pass
            return

        wc = conf.get("welcome_channel_id", 0)
        ch = guild.get_channel(wc) if wc else None
        if ch:
            e = discord.Embed(
                title=f"👋 Bienvenido {member.name}",
                description=(
                    f"Bienvenido a **{guild.name}**, {member.mention}!\n"
                    f"Eres el miembro #{guild.member_count}."
                ),
                color=discord.Color.green(),
            )
            e.set_thumbnail(url=member.display_avatar.url)
            try:
                await ch.send(embed=e)
            except (discord.Forbidden, discord.HTTPException):
                pass

        # DM de bienvenida con instrucciones si hay verificación
        if conf.get("verify_role_id", 0):
            try:
                await member.send(
                    f"¡Bienvenido a **{guild.name}**! 🛡\n"
                    "Pásate por el canal de verificación y pulsa el botón **Verificarme**."
                )
            except (discord.Forbidden, discord.HTTPException):
                pass

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        # Detecta kicks para el anti-nuke (el log de salida está en logs.py)
        e = await self._executor(member.guild, discord.AuditLogAction.kick, member)
        if e:
            await self._nuke_check(member.guild, e, "kickeo", f"Kickeo de {member}")

    # --------------------------------------------------------- anti-nuke events
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        user = await self._executor(channel.guild, discord.AuditLogAction.channel_delete, channel)
        await self._nuke_check(channel.guild, user, "canal_borrado", f"Canal borrado: #{channel.name}")

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        user = await self._executor(channel.guild, discord.AuditLogAction.channel_create, channel)
        await self._nuke_check(channel.guild, user, "canal_creado", f"Canal creado: #{channel.name}")

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        if role.is_default():
            return
        user = await self._executor(role.guild, discord.AuditLogAction.role_delete, role)
        await self._nuke_check(role.guild, user, "rol_borrado", f"Rol borrado: @{role.name}")

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        e = await self._executor(guild, discord.AuditLogAction.ban, user)
        await self._nuke_check(guild, e, "baneo", f"Baneo de {user}")

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        guild = channel.guild
        for action in (discord.AuditLogAction.webhook_create, discord.AuditLogAction.webhook_delete):
            try:
                async for entry in guild.audit_logs(limit=3, action=action):
                    age = (discord.utils.utcnow() - entry.created_at).total_seconds()
                    if age < 15:
                        await self._nuke_check(
                            guild, entry.user, "webhook",
                            f"Webhook {'creado' if action == discord.AuditLogAction.webhook_create else 'borrado'} en #{channel.name}",
                        )
                        break
            except (discord.Forbidden, discord.HTTPException):
                pass


async def setup(bot):
    await bot.add_cog(Security(bot))
