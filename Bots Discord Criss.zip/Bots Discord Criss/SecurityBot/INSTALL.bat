@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   SecurityBot - Instalador de dependencias
echo ============================================
set PY=
where python >nul 2>nul && set PY=python
if "%PY%"=="" (
    where py >nul 2>nul && set PY=py
)
if "%PY%"=="" (
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe
)
if "%PY%"=="" (
    echo ERROR: No se encontro Python. Instalalo desde python.org
    pause
    exit /b 1
)
echo Usando Python: %PY%
%PY% -m venv venv
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo ============================================
echo   Instalacion completa!
echo   Ahora ejecuta START_BOT.bat
echo ============================================
pause
