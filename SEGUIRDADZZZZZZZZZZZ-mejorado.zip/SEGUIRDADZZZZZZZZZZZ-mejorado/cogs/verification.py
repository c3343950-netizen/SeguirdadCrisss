from __future__ import annotations
import secrets, discord
from discord import app_commands
from discord.ext import commands
from helpers import base_embed, send_log
class VerifyView(discord.ui.View):
    def __init__(self, cog): super().__init__(timeout=None); self.cog=cog
    @discord.ui.button(label='Verificarme',style=discord.ButtonStyle.success,emoji='✅',custom_id='verify:start')
    async def verify_button(self,interaction:discord.Interaction,button:discord.ui.Button):
        if not interaction.guild or not isinstance(interaction.user,discord.Member):
            return await interaction.response.send_message('Usa este botón dentro del servidor.',ephemeral=True)
        if await self.cog.verify_member(interaction.user):
            await interaction.response.send_message('✅ Verificación completada. ¡Bienvenido!',ephemeral=True)
        else: await interaction.response.send_message('No pude verificarte. Contacta al equipo de moderación.',ephemeral=True)
class Verification(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.bot.add_view(VerifyView(self))
    async def verify_member(self,member):
        g=member.guild; rid=await self.bot.db.get_int(g.id,'verified_role_id'); role=g.get_role(rid)
        if role:
            try: await member.add_roles(role,reason='Verificación del servidor')
            except discord.Forbidden: return False
        await self.bot.db.set_setting(g.id,f'verified_{member.id}','true')
        await self.bot.db.add_security_event(g.id,'verified',member.id,'Verificación mediante botón')
        e=base_embed('Usuario verificado',0x57F287); e.description=f'{member.mention} completó la verificación.'
        await send_log(g,self.bot.db,'log_verify_channel',e)
        return True
    @commands.Cog.listener()
    async def on_member_join(self,member):
        if member.bot and await self.bot.db.get_bool(member.guild.id,'autoverify_bots'): return
        if not await self.bot.db.get_bool(member.guild.id,'verification_enabled'): return
        rid=await self.bot.db.get_int(member.guild.id,'unverified_role_id'); role=member.guild.get_role(rid)
        if role:
            try: await member.add_roles(role,reason='Rol inicial de verificación')
            except discord.Forbidden: pass
    @app_commands.command(name='panelverificacion',description='Publica el panel de verificación en este canal')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def panel(self,interaction:discord.Interaction):
        if not interaction.channel: return await interaction.response.send_message('Canal no disponible.',ephemeral=True)
        e=base_embed('Verificación del servidor',0x5865F2); e.description='Pulsa **Verificarme** para recibir acceso. Si tienes problemas, contacta con moderación.'
        await interaction.channel.send(embed=e,view=VerifyView(self)); await interaction.response.send_message('Panel publicado.',ephemeral=True)
    @app_commands.command(name='verificar',description='Verifica manualmente a un miembro')
    @app_commands.checks.has_permissions(manage_roles=True)
    async def verify_cmd(self,interaction:discord.Interaction,usuario:discord.Member):
        ok=await self.verify_member(usuario); await interaction.response.send_message('Verificación aplicada.' if ok else 'No se pudo aplicar; revisa permisos y rol.',ephemeral=True)
async def setup(bot): await bot.add_cog(Verification(bot))
