import discord
from discord.ext import commands
from helpers import base_embed, send_log
class Audit(commands.Cog):
    def __init__(self,bot): self.bot=bot
    async def record(self,guild,kind,detail):
        await self.bot.db.add_security_event(guild.id,kind,None,detail)
        e=base_embed('📋 Auditoría: '+kind,0x5865F2); e.description=detail[:4000]
        await send_log(guild,self.bot.db,'log_mod_channel',e)
    @commands.Cog.listener()
    async def on_member_join(self,member):
        channel_id=await self.bot.db.get_int(member.guild.id,'welcome_channel_id'); channel=member.guild.get_channel(channel_id) if channel_id else None
        if channel:
            template=await self.bot.db.get_setting(member.guild.id,'welcome_message')
            try: await channel.send(template.replace('{mention}',member.mention).replace('{name}',discord.utils.escape_markdown(member.display_name)).replace('{guild}',discord.utils.escape_markdown(member.guild.name)))
            except discord.HTTPException: pass
        role_ids=(await self.bot.db.get_setting(member.guild.id,'auto_role_ids')).split(',')
        roles=[member.guild.get_role(int(x.strip())) for x in role_ids if x.strip().isdigit() and int(x.strip())>0]
        roles=[r for r in roles if r and r < member.guild.me.top_role]
        if roles:
            try: await member.add_roles(*roles,reason='Auto-roles de bienvenida')
            except discord.HTTPException: pass
    @commands.Cog.listener()
    async def on_member_update(self,before,after):
        if before.roles!=after.roles:
            added=[r.name for r in after.roles if r not in before.roles]; removed=[r.name for r in before.roles if r not in after.roles]
            await self.record(after.guild,'roles_changed',f'{after} ({after.id}) | añadidos: {added or "ninguno"} | retirados: {removed or "ninguno"}')
        if before.nick!=after.nick: await self.record(after.guild,'nickname_changed',f'{after.id}: {before.nick!r} → {after.nick!r}')
    @commands.Cog.listener()
    async def on_guild_channel_create(self,ch): await self.record(ch.guild,'channel_created',f'{ch.name} ({ch.id}) tipo={ch.type}')
    @commands.Cog.listener()
    async def on_guild_channel_update(self,before,after):
        changes=[]
        for attr in ('name','topic','slowmode_delay','nsfw'):
            if getattr(before,attr,None)!=getattr(after,attr,None): changes.append(f'{attr}: {getattr(before,attr,None)!r} → {getattr(after,attr,None)!r}')
        if changes: await self.record(after.guild,'channel_updated',f'{after.id}: '+ '; '.join(changes))
    @commands.Cog.listener()
    async def on_guild_role_create(self,role): await self.record(role.guild,'role_created',f'{role.name} ({role.id})')
    @commands.Cog.listener()
    async def on_guild_role_update(self,before,after):
        if before.name!=after.name or before.permissions!=after.permissions: await self.record(after.guild,'role_updated',f'{after.id}: nombre {before.name!r} → {after.name!r}; permisos cambiados={before.permissions!=after.permissions}')
    @commands.Cog.listener()
    async def on_member_remove(self,member):
        channel_id=await self.bot.db.get_int(member.guild.id,'goodbye_channel_id'); channel=member.guild.get_channel(channel_id) if channel_id else None
        if channel:
            template=await self.bot.db.get_setting(member.guild.id,'goodbye_message')
            try: await channel.send(template.replace('{name}',discord.utils.escape_markdown(member.display_name)).replace('{guild}',discord.utils.escape_markdown(member.guild.name)))
            except discord.HTTPException: pass
    @commands.Cog.listener()
    async def on_member_ban(self,guild,user): await self.record(guild,'member_banned',f'{user} ({user.id})')
    @commands.Cog.listener()
    async def on_member_unban(self,guild,user): await self.record(guild,'member_unbanned',f'{user} ({user.id})')
async def setup(bot): await bot.add_cog(Audit(bot))
