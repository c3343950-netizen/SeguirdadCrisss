import discord
from discord.ext import commands
from discord import app_commands
from helpers import base_embed, send_log

class TicketView(discord.ui.View):
    def __init__(self, cog): super().__init__(timeout=None); self.cog=cog
    @discord.ui.button(label='Abrir ticket',style=discord.ButtonStyle.primary,emoji='🎫',custom_id='ticket:open')
    async def open_ticket(self, interaction:discord.Interaction, button:discord.ui.Button):
        g=interaction.guild
        if not g or not isinstance(interaction.user,discord.Member): return await interaction.response.send_message('Disponible solo en un servidor.',ephemeral=True)
        existing=discord.utils.get(g.text_channels,name=f'ticket-{interaction.user.id}')
        if existing: return await interaction.response.send_message(f'Ya tienes un ticket: {existing.mention}',ephemeral=True)
        category_id=await self.cog.bot.db.get_int(g.id,'ticket_category_id'); category=g.get_channel(category_id) if category_id else None
        overwrites={g.default_role:discord.PermissionOverwrite(view_channel=False),interaction.user:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True),g.me:discord.PermissionOverwrite(view_channel=True,send_messages=True,manage_channels=True)}
        staff_id=await self.cog.bot.db.get_int(g.id,'ticket_staff_role_id'); staff=g.get_role(staff_id) if staff_id else None
        if staff: overwrites[staff]=discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)
        try: ch=await g.create_text_channel(f'ticket-{interaction.user.id}',category=category,overwrites=overwrites,topic=f'Ticket de {interaction.user} ({interaction.user.id})')
        except discord.HTTPException: return await interaction.response.send_message('No pude crear el ticket. Revisa permisos.',ephemeral=True)
        await ch.send(f'{interaction.user.mention} describe tu consulta. El equipo te atenderá pronto.',view=CloseView(self.cog))
        await self.cog.bot.db.add_security_event(g.id,'ticket_open',interaction.user.id,f'canal={ch.id}')
        await interaction.response.send_message(f'Ticket creado: {ch.mention}',ephemeral=True)
class CloseView(discord.ui.View):
    def __init__(self,cog): super().__init__(timeout=None); self.cog=cog
    @discord.ui.button(label='Cerrar ticket',style=discord.ButtonStyle.danger,emoji='🔒',custom_id='ticket:close')
    async def close(self,interaction:discord.Interaction,button:discord.ui.Button):
        ch=interaction.channel; g=interaction.guild
        if not isinstance(ch,discord.TextChannel) or not ch.name.startswith('ticket-'): return await interaction.response.send_message('Este canal no parece un ticket.',ephemeral=True)
        owner_id=int(ch.name.removeprefix('ticket-'))
        staff_id=await self.cog.bot.db.get_int(g.id,'ticket_staff_role_id')
        if interaction.user.id!=owner_id and not interaction.user.guild_permissions.manage_channels and not any(r.id==staff_id for r in getattr(interaction.user,'roles',[])):
            return await interaction.response.send_message('Solo el dueño del ticket o el equipo puede cerrarlo.',ephemeral=True)
        await self.cog.bot.db.add_security_event(g.id,'ticket_close',interaction.user.id,f'canal={ch.id}')
        await interaction.response.send_message('Ticket cerrado. El canal se eliminará en unos segundos.')
        await __import__('asyncio').sleep(4)
        try: await ch.delete(reason=f'Ticket cerrado por {interaction.user}')
        except discord.HTTPException: pass
class Tickets(commands.Cog):
    def __init__(self,bot): self.bot=bot; bot.add_view(TicketView(self)); bot.add_view(CloseView(self))
    @app_commands.command(name='paneltickets',description='Publica el panel para abrir tickets')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def panel(self,interaction:discord.Interaction):
        e=base_embed('Centro de soporte',0x5865F2); e.description='Pulsa el botón para abrir un canal privado con el equipo de soporte.'
        await interaction.channel.send(embed=e,view=TicketView(self)); await interaction.response.send_message('Panel de tickets publicado.',ephemeral=True)
    @app_commands.command(name='ticketconfig',description='Configura categoría y rol de soporte')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ticketconfig(self,interaction:discord.Interaction,categoria:discord.CategoryChannel|None=None,rol_staff:discord.Role|None=None):
        if categoria: await self.bot.db.set_setting(interaction.guild_id,'ticket_category_id',categoria.id)
        if rol_staff: await self.bot.db.set_setting(interaction.guild_id,'ticket_staff_role_id',rol_staff.id)
        await interaction.response.send_message('Configuración de tickets actualizada.',ephemeral=True)
async def setup(bot): await bot.add_cog(Tickets(bot))
