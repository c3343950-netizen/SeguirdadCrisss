from __future__ import annotations
import time, discord
from discord import app_commands
from discord.ext import commands
from helpers import base_embed, send_log
class AntiRaid(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.joins={}; self.raid_until={}
    @commands.Cog.listener()
    async def on_member_join(self, member):
        g=member.guild; now=time.monotonic(); window=await self.bot.db.get_int(g.id,'raid_window_seconds') or 15
        q=self.joins.setdefault(g.id,[]); q[:]=[t for t in q if now-t<window]; q.append(now)
        threshold=await self.bot.db.get_int(g.id,'raid_join_threshold') or 10
        if len(q)>=threshold:
            self.raid_until[g.id]=now+(await self.bot.db.get_int(g.id,'raid_cooldown_seconds') or 300)
            await self.bot.db.add_security_event(g.id,'raid_detected',member.id,f'{len(q)} entradas en {window}s')
            e=base_embed('🚨 Posible raid detectado',0xED4245); e.description=f'{len(q)} entradas en {window} segundos. Revisa la actividad reciente.'
            await send_log(g,self.bot.db,'log_raid_channel',e)
        age=(discord.utils.utcnow()-member.created_at).days
        min_age=await self.bot.db.get_int(g.id,'min_account_age_days')
        if min_age>0 and age<min_age and (self.raid_until.get(g.id,0)>now) and await self.bot.db.get_bool(g.id,'raid_kick_new_accounts'):
            try:
                await member.kick(reason=f'Anti-raid: cuenta con {age} días; mínimo configurado {min_age}')
                await self.bot.db.add_security_event(g.id,'raid_kick',member.id,f'edad cuenta={age} días')
            except discord.Forbidden: pass
    @app_commands.command(name='raidmode',description='Consultar o cambiar el modo raid')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def raidmode(self,interaction:discord.Interaction,activar:bool):
        if activar: self.raid_until[interaction.guild_id]=time.monotonic()+300
        else: self.raid_until.pop(interaction.guild_id,None)
        await interaction.response.send_message(f'Modo raid: {"ACTIVADO (5 min)" if activar else "desactivado"}.',ephemeral=True)
async def setup(bot): await bot.add_cog(AntiRaid(bot))
