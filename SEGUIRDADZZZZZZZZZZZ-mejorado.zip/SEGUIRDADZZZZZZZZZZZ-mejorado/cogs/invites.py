from __future__ import annotations
import discord
from discord import app_commands
from discord.ext import commands
from helpers import base_embed

class Invites(commands.Cog):
    def __init__(self, bot):
        self.bot=bot
        self.cache={}
    async def refresh(self, guild):
        try: self.cache[guild.id]={i.code:i.uses for i in await guild.invites()}
        except (discord.Forbidden, discord.HTTPException): self.cache[guild.id]={}
    @commands.Cog.listener()
    async def on_ready(self):
        for g in self.bot.guilds: await self.refresh(g)
    @commands.Cog.listener()
    async def on_member_join(self, member):
        before=self.cache.get(member.guild.id,{})
        inviter=None; code=None
        try:
            current=await member.guild.invites()
            for inv in current:
                if inv.uses and inv.uses > before.get(inv.code,0):
                    inviter=inv.inviter; code=inv.code; break
            self.cache[member.guild.id]={i.code:i.uses for i in current}
        except (discord.Forbidden, discord.HTTPException): pass
        previous=await self.bot.db.count_previous_joins(member.guild.id,member.id)
        fake=(member.created_at and (discord.utils.utcnow()-member.created_at).days < await self.bot.db.get_int(member.guild.id,'min_account_age_days'))
        await self.bot.db.add_invite_join(member.guild.id,member.id,inviter.id if inviter else None,code,bool(fake))
        if inviter:
            await self.bot.db.bump_invite_stat(member.guild.id,inviter.id,'joins')
            if previous: await self.bot.db.bump_invite_stat(member.guild.id,inviter.id,'rejoin')
            if fake: await self.bot.db.bump_invite_stat(member.guild.id,inviter.id,'fake')
        await self.bot.db.add_security_event(member.guild.id,'member_join',member.id,f'invitador={inviter.id if inviter else "desconocido"}; cuenta_nueva={bool(fake)}')
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        inviter=await self.bot.db.last_inviter_of(member.guild.id,member.id)
        if inviter: await self.bot.db.bump_invite_stat(member.guild.id,inviter,'leaves')
    @app_commands.command(name='invites',description='Ver estadísticas de invitaciones')
    async def invites(self, interaction: discord.Interaction, usuario: discord.Member|None=None):
        target=usuario or interaction.user; d=await self.bot.db.get_invite_stats(interaction.guild_id,target.id)
        e=base_embed(f'Invitaciones de {target}',0x5865F2)
        e.add_field(name='Entradas',value=d['joins']); e.add_field(name='Salidas',value=d['leaves']); e.add_field(name='Falsas',value=d['fake']); e.add_field(name='Reingresos',value=d['rejoin']); e.add_field(name='Estimadas activas',value=max(0,d['real']))
        await interaction.response.send_message(embed=e,ephemeral=True)
    @app_commands.command(name='topinvites',description='Ranking de invitadores')
    async def topinvites(self, interaction: discord.Interaction):
        rows=await self.bot.db.top_inviters(interaction.guild_id,10)
        lines=[f'**{i+1}.** <@{r["user_id"]}> — **{max(0,r["real"])}** activas ({r["joins"]} entradas)' for i,r in enumerate(rows)]
        await interaction.response.send_message('\n'.join(lines) or 'Todavía no hay datos.',ephemeral=True)
async def setup(bot): await bot.add_cog(Invites(bot))
