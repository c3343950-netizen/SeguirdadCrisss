import re, discord
from discord.ext import commands
from discord import app_commands
from helpers import base_embed, send_log
class AutoMod(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.warned=set()
    @commands.Cog.listener()
    async def on_message(self,message):
        if not message.guild or message.author.bot or (isinstance(message.author,discord.Member) and message.author.guild_permissions.manage_messages): return
        g=message.guild; reasons=[]
        if await self.bot.db.get_bool(g.id,'automod_links') and re.search(r'https?://|discord\.gg/',message.content,re.I): reasons.append('enlace')
        if await self.bot.db.get_bool(g.id,'automod_invites') and re.search(r'(discord\.gg/|discord(app)?\.com/invite/)',message.content,re.I): reasons.append('invitación Discord')
        words=(await self.bot.db.get_setting(g.id,'automod_blocked_words')).split('|')
        lower=message.content.casefold()
        if any(w.strip() and w.strip().casefold() in lower for w in words): reasons.append('palabra bloqueada')
        mention_limit=await self.bot.db.get_int(g.id,'automod_mention_limit')
        if mention_limit>0 and len(message.mentions)+len(message.role_mentions)>=mention_limit: reasons.append('menciones masivas')
        if not reasons: return
        try: await message.delete()
        except discord.HTTPException: pass
        action=(await self.bot.db.get_setting(g.id,'automod_action')).lower()
        try:
            if action=='timeout' and isinstance(message.author,discord.Member): await message.author.timeout(__import__('datetime').timedelta(minutes=5),reason='AutoMod: '+', '.join(reasons))
            elif action=='kick' and isinstance(message.author,discord.Member): await message.author.kick(reason='AutoMod: '+', '.join(reasons))
            elif action=='ban' and isinstance(message.author,discord.Member): await message.author.ban(reason='AutoMod: '+', '.join(reasons),delete_message_seconds=0)
        except discord.HTTPException: pass
        await self.bot.db.add_security_event(g.id,'automod',message.author.id,'motivos='+','.join(reasons)+'; accion='+action)
        e=base_embed('AutoMod: mensaje bloqueado',0xED4245); e.description=f'{message.author.mention} | Motivos: {", ".join(reasons)} | Acción: {action}'
        await send_log(g,self.bot.db,'log_security_channel',e)
    @app_commands.command(name='automodconfig',description='Configura filtros automáticos del servidor')
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.choices(filtro=[app_commands.Choice(name='Enlaces',value='automod_links'),app_commands.Choice(name='Invitaciones Discord',value='automod_invites'),app_commands.Choice(name='Menciones masivas (límite)',value='automod_mention_limit'),app_commands.Choice(name='Palabras bloqueadas (separadas por |)',value='automod_blocked_words'),app_commands.Choice(name='Acción',value='automod_action')])
    async def automodconfig(self,interaction:discord.Interaction,filtro:app_commands.Choice[str],valor:str):
        key=filtro.value
        if key in ('automod_links','automod_invites') and valor.lower() not in ('true','false','1','0'): return await interaction.response.send_message('Usa true o false.',ephemeral=True)
        if key=='automod_mention_limit':
            try:
                if not 0<=int(valor)<=50: raise ValueError
            except ValueError: return await interaction.response.send_message('Usa un número entre 0 y 50 (0 desactiva).',ephemeral=True)
        if key=='automod_action' and valor.lower() not in ('delete','timeout','kick','ban'): return await interaction.response.send_message('Acciones: delete, timeout, kick, ban.',ephemeral=True)
        if len(valor)>500: return await interaction.response.send_message('Valor demasiado largo.',ephemeral=True)
        await self.bot.db.set_setting(interaction.guild_id,key,valor.lower() if key!='automod_blocked_words' else valor)
        await interaction.response.send_message(f'AutoMod actualizado: `{key}`.',ephemeral=True)
async def setup(bot): await bot.add_cog(AutoMod(bot))
