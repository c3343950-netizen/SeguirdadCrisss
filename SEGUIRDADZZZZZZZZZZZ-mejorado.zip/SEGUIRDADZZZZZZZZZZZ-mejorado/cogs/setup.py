from __future__ import annotations
import discord
from discord import app_commands
from discord.ext import commands
from helpers import base_embed

KEYS={'log_join_channel','log_leave_channel','log_invite_channel','log_raid_channel','log_security_channel','log_verify_channel','verified_role_id','unverified_role_id','raid_join_threshold','raid_window_seconds','raid_cooldown_seconds','min_account_age_days','spam_msg_threshold','spam_msg_window','spam_mention_limit','spam_action','spam_timeout_minutes','verification_enabled','antinuke_enabled','antinuke_action','antinuke_threshold','automod_links','automod_invites','automod_mention_limit','automod_blocked_words','automod_action','welcome_channel_id','welcome_message','goodbye_channel_id','goodbye_message','ticket_category_id','ticket_staff_role_id','auto_role_ids','verify_panel_channel'}
class Setup(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @app_commands.command(name='config',description='Cambiar una opción del bot')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def config_cmd(self,interaction:discord.Interaction,clave:str,valor:str):
        if clave not in KEYS: return await interaction.response.send_message('Clave no permitida. Usa /opciones para ver ajustes conocidos.',ephemeral=True)
        if len(valor)>300: return await interaction.response.send_message('Valor demasiado largo.',ephemeral=True)
        if clave in {'raid_join_threshold','raid_window_seconds','raid_cooldown_seconds','min_account_age_days','spam_msg_threshold','spam_msg_window','spam_mention_limit','spam_timeout_minutes','verified_role_id','unverified_role_id','verify_panel_channel','log_join_channel','log_leave_channel','log_invite_channel','log_raid_channel','log_security_channel','log_verify_channel'}:
            try:
                if int(valor)<0: raise ValueError
            except ValueError: return await interaction.response.send_message('Esta opción requiere un número entero no negativo.',ephemeral=True)
        if clave in {'spam_action','automod_action','antinuke_action'} and valor.lower() not in {'delete','timeout','kick','ban'}: return await interaction.response.send_message('Acciones válidas: delete, timeout, kick, ban.',ephemeral=True)
        if clave in {'verification_enabled'} and valor.lower() not in {'true','false','1','0','yes','no'}: return await interaction.response.send_message('Usa true o false.',ephemeral=True)
        await self.bot.db.set_setting(interaction.guild_id,clave,valor.lower() if valor.lower() in {'true','false','yes','no'} else valor)
        await interaction.response.send_message(f'Configuración actualizada: `{clave} = {valor}`',ephemeral=True)
    @app_commands.command(name='opciones',description='Ver las opciones configuradas')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def opciones(self,interaction:discord.Interaction):
        settings=await self.bot.db.all_settings(interaction.guild_id)
        e=base_embed('Configuración del bot',0x5865F2)
        for k,v in list(settings.items())[:24]: e.add_field(name=k,value=f'`{v[:90]}`',inline=True)
        await interaction.response.send_message(embed=e,ephemeral=True)
    @app_commands.command(name='canales',description='Configura el canal de registro de un evento')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def canales(self,interaction:discord.Interaction,tipo:str,canal:discord.TextChannel):
        mapping={'entradas':'log_join_channel','salidas':'log_leave_channel','invitaciones':'log_invite_channel','raid':'log_raid_channel','seguridad':'log_security_channel','verificacion':'log_verify_channel'}
        key=mapping.get(tipo.lower())
        if not key: return await interaction.response.send_message('Tipos: entradas, salidas, invitaciones, raid, seguridad, verificacion.',ephemeral=True)
        await self.bot.db.set_setting(interaction.guild_id,key,canal.id)
        await interaction.response.send_message(f'Los registros de **{tipo}** irán a {canal.mention}.',ephemeral=True)
async def setup(bot): await bot.add_cog(Setup(bot))
