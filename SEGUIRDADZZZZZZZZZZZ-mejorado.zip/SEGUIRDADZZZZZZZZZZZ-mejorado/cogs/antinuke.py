from collections import defaultdict, deque
import time, discord
from discord.ext import commands
from discord import app_commands
from helpers import base_embed, send_log

class AntiNuke(commands.Cog):
    """Detecta acciones destructivas repetidas mediante Audit Log; no sustituye permisos mínimos."""
    def __init__(self, bot): self.bot=bot; self.actions=defaultdict(deque)
    async def check(self, guild, action, target):
        if not await self.bot.db.get_bool(guild.id, 'antinuke_enabled'): return
        await __import__('asyncio').sleep(1.2)  # audit log puede tardar en aparecer
        try:
            async for entry in guild.audit_logs(limit=8, action=action):
                if entry.target and getattr(entry.target,'id',None)==getattr(target,'id',None) and (discord.utils.utcnow()-entry.created_at).total_seconds()<12:
                    actor=entry.user
                    if not actor or actor.id==guild.owner_id or actor.bot: return
                    if await self.bot.db.get_bool(guild.id,f'trusted_{actor.id}'): return
                    if isinstance(actor,discord.Member) and actor.guild_permissions.administrator: return
                    now=time.monotonic(); q=self.actions[(guild.id,actor.id)]; q.append(now)
                    while q and now-q[0]>30: q.popleft()
                    threshold=await self.bot.db.get_int(guild.id,'antinuke_threshold') or 3
                    if len(q)>=threshold:
                        q.clear(); mode=(await self.bot.db.get_setting(guild.id,'antinuke_action')).lower()
                        try:
                            if mode=='ban': await guild.ban(actor,reason='Anti-nuke: acciones destructivas repetidas',delete_message_seconds=0)
                            elif mode=='timeout' and isinstance(actor,discord.Member): await actor.timeout(__import__('datetime').timedelta(minutes=30),reason='Anti-nuke')
                        except discord.HTTPException: pass
                        await self.bot.db.add_security_event(guild.id,'antinuke',actor.id,f'accion={action.name}; modo={mode}')
                        e=base_embed('🚨 Anti-nuke: actividad sospechosa',0xED4245); e.description=f'Actor: {actor.mention} (`{actor.id}`)\nAcción: `{action.name}`\nMedida: `{mode}`'
                        await send_log(guild,self.bot.db,'log_security_channel',e)
                    return
        except (discord.Forbidden,discord.HTTPException): return
    @commands.Cog.listener()
    async def on_guild_channel_delete(self,ch): await self.check(ch.guild,discord.AuditLogAction.channel_delete,ch)
    @commands.Cog.listener()
    async def on_guild_role_delete(self,role): await self.check(role.guild,discord.AuditLogAction.role_delete,role)
    @commands.Cog.listener()
    async def on_member_ban(self,guild,user): await self.check(guild,discord.AuditLogAction.ban,user)
    @app_commands.command(name='confiar',description='Eximir a un miembro de las acciones anti-nuke')
    @app_commands.checks.has_permissions(administrator=True)
    async def confiar(self, interaction:discord.Interaction, usuario:discord.Member):
        await self.bot.db.set_setting(interaction.guild_id,f'trusted_{usuario.id}',True)
        await interaction.response.send_message(f'{usuario.mention} añadido a la lista de confianza.',ephemeral=True)
    @app_commands.command(name='noconfiar',description='Quitar a un miembro de la lista de confianza')
    @app_commands.checks.has_permissions(administrator=True)
    async def noconfiar(self, interaction:discord.Interaction, usuario:discord.Member):
        await self.bot.db.set_setting(interaction.guild_id,f'trusted_{usuario.id}',False)
        await interaction.response.send_message(f'{usuario.mention} ya no está exento.',ephemeral=True)
async def setup(bot): await bot.add_cog(AntiNuke(bot))
