from __future__ import annotations
import time, discord
from discord import app_commands
from discord.ext import commands
from helpers import base_embed, send_log
class Security(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.messages={}
    @commands.Cog.listener()
    async def on_message(self,message):
        if not message.guild or message.author.bot: return
        g=message.guild; now=time.monotonic(); key=(g.id,message.author.id); window=await self.bot.db.get_int(g.id,'spam_msg_window') or 5
        q=self.messages.setdefault(key,[]); q[:]=[t for t in q if now-t<window]; q.append(now)
        threshold=await self.bot.db.get_int(g.id,'spam_msg_threshold') or 6
        mentions=await self.bot.db.get_int(g.id,'spam_mention_limit') or 6
        if len(q)<threshold and len(message.mentions)<mentions: return
        q.clear()
        try: await message.delete()
        except discord.HTTPException: pass
        action=(await self.bot.db.get_setting(g.id,'spam_action')).lower()
        try:
            if action=='timeout' and isinstance(message.author,discord.Member):
                await message.author.timeout(__import__('datetime').timedelta(minutes=max(1,await self.bot.db.get_int(g.id,'spam_timeout_minutes'))),reason='Anti-spam automático')
            elif action=='kick' and isinstance(message.author,discord.Member): await message.author.kick(reason='Anti-spam automático')
            elif action=='ban' and isinstance(message.author,discord.Member): await message.author.ban(reason='Anti-spam automático',delete_message_seconds=0)
        except discord.HTTPException: pass
        await self.bot.db.add_security_event(g.id,'anti_spam',message.author.id,f'accion={action}; menciones={len(message.mentions)}')
        e=base_embed('Anti-spam activado',0xED4245); e.description=f'{message.author.mention} activó el filtro automático. Acción configurada: **{action}**.'
        await send_log(g,self.bot.db,'log_security_channel',e)
    @commands.Cog.listener()
    async def on_member_remove(self,member):
        e=base_embed('Miembro salió',0xFAA61A); e.description=f'{member} (`{member.id}`) salió del servidor.'
        await send_log(member.guild,self.bot.db,'log_leave_channel',e)
    @commands.Cog.listener()
    async def on_member_join(self,member):
        e=base_embed('Nuevo miembro',0x57F287); e.description=f'{member.mention} (`{member.id}`) se unió. Cuenta creada: <t:{int(member.created_at.timestamp())}:R>.'
        await send_log(member.guild,self.bot.db,'log_join_channel',e)
    @app_commands.command(name='eventos',description='Ver eventos recientes de seguridad')
    @app_commands.checks.has_permissions(view_audit_log=True)
    async def eventos(self,interaction:discord.Interaction,cantidad:app_commands.Range[int,1,15]=10):
        rows=await self.bot.db.recent_security_events(interaction.guild_id,cantidad)
        lines=[f'• <t:{r["created_at"]}:R> **{r["kind"]}** — {("<@"+str(r["user_id"])+"> ") if r["user_id"] else ""}{(r["detail"] or "")[:120]}' for r in rows]
        await interaction.response.send_message('\n'.join(lines) or 'No hay eventos registrados.',ephemeral=True)
    @app_commands.command(name='seguridad',description='Estado básico del bot de seguridad')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def seguridad(self,interaction:discord.Interaction):
        e=base_embed('Estado de seguridad',0x5865F2); e.add_field(name='Base de datos',value='Conectada' if self.bot.db.conn else 'Desconectada'); e.add_field(name='Miembros',value=interaction.guild.member_count or 0); e.add_field(name='Latencia',value=f'{round(self.bot.latency*1000)} ms')
        await interaction.response.send_message(embed=e,ephemeral=True)
async def setup(bot): await bot.add_cog(Security(bot))
