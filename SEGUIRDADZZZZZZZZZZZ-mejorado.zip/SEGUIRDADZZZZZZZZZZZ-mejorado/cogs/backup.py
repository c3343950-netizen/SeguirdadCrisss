import io, json, time, discord
from discord.ext import commands
from discord import app_commands
class Backup(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @app_commands.command(name='exportarconfig',description='Exporta la configuración y eventos recientes del servidor')
    @app_commands.checks.has_permissions(administrator=True)
    async def exportar(self,interaction:discord.Interaction):
        guild_id=interaction.guild_id
        data={'guild_id':guild_id,'exported_at':int(time.time()),'settings':await self.bot.db.all_settings(guild_id),'recent_events':await self.bot.db.recent_security_events(guild_id,100)}
        payload=json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8')
        await interaction.response.send_message('Exportación lista. Contiene configuración y eventos; no incluye tokens ni credenciales.',file=discord.File(io.BytesIO(payload),filename=f'seguridad-{guild_id}-{int(time.time())}.json'),ephemeral=True)
async def setup(bot): await bot.add_cog(Backup(bot))
