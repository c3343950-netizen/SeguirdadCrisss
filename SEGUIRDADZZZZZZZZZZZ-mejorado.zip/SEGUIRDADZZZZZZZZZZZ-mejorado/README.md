# Bot de Invitaciones + Seguridad (Anti-Raid) + Verificación Obligatoria

Bot de Discord que combina:

1. **Sistema de invitaciones** — rastrea quién invitó a quién, estadísticas (entradas, salidas, falsas, reingresos) y ranking.
2. **Anti-raid** — detecta avalanchas de entradas, bloquea canales y expulsa cuentas nuevas automáticamente.
3. **Verificación obligatoria** — sin verificar no hay acceso al resto de canales.
4. **Anti-spam y anti-nuke** — castiga spam, menciones masivas y acciones destructivas en masa.
5. **Registro por canales separados** — cada evento va a su propio canal, incluyendo la **IP** del usuario cuando se conoce.

---

## ⚠️ Nota importante sobre la IP

**Discord NO entrega la IP de los usuarios a los bots.** No existe ningún endpoint que la exponga.

La única forma legítima de obtenerla es cuando el usuario abre una **página web que tú controlas**. Por eso el bot incluye un servidor web de verificación (`webverify.py`): al verificar, se captura la IP real de la conexión y se registra en el canal de seguridad junto con el evento.

- Si un usuario nunca pasó por la verificación web, el campo IP aparece como `Desconocida`.
- En el canal de seguridad se registra la **última IP conocida** del infractor (de su verificación).
- Detrás de proxy/CDN pon `TRUST_PROXY_HEADERS=true` para usar `X-Forwarded-For`.

---

## Estructura

```
discord-security-bot/
├── bot.py              # Entrada principal
├── config.py           # Configuración desde .env
├── database.py         # SQLite asíncrono
├── helpers.py          # Utilidades y envío de logs
├── webverify.py        # Servidor Flask (captura de IP)
├── requirements.txt
├── .env.example
└── cogs/
    ├── invites.py      # Invitaciones y estadísticas
    ├── antiraid.py     # Anti-raid y lockdown
    ├── verification.py # Verificación obligatoria
    ├── security.py     # Anti-spam, anti-nuke, eventos
    └── setup.py        # /config, /canales, /opciones
```

---

## Instalación

```bash
cd discord-security-bot
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env      # Windows  (cp en Linux/Mac)
# Edita .env con tu token, ID del servidor y URL pública
python bot.py
```

### Permisos del bot (Discord Developer Portal)

- **Bot → Privileged Gateway Intents**: activa PRESENCE, **SERVER MEMBERS** y **MESSAGE CONTENT**.
- **Permisos recomendados** al invitarlo: `Manage Roles`, `Manage Channels`, `Kick Members`, `Ban Members`, `Moderate Members`, `Manage Messages`, `View Audit Log`, `Send Messages`, `Embed Links`.
- El rol del bot **debe estar por encima** de los roles que gestiona.

---

## Configuración inicial

### 1. Variables `.env`

```env
DISCORD_TOKEN=...
GUILD_ID=123456789012345678
WEB_VERIFY_ENABLED=true
WEB_VERIFY_PUBLIC_URL=http://TU_IP_PUBLICA:8080
VERIFY_SECRET=un_string_largo_y_aleatorio
```

### 2. Canales de registro (uno por tipo)

```
/canales tipo:Entradas            canal:#logs-entradas
/canales tipo:Salidas             canal:#logs-salidas
/canales tipo:Invitaciones        canal:#logs-invitaciones
/canales tipo:Alertas de raid     canal:#logs-raid
/canales tipo:Seguridad           canal:#logs-seguridad
/canales tipo: Verificacion       canal:#logs-verificacion
```

Cada tipo de evento cae en **su propio canal**, como pediste.

### 3. Verificación en un canal concreto (id) + bloqueo real

**La verificación ocurre en UN solo canal, identificado por su ID**, y mientras
el usuario no esté verificado **no puede ver ni entrar** a ningún otro canal
(texto, voz, foro o categoría).

La forma más rápida (crea los roles, el canal, el bloqueo y el panel):

```
/setupverificacion
```

O paso a paso:

```
# 1) Fija el canal de verificación por canal o por ID
/canalverificacion canal:#verificacion
/canalverificacion id_canal:123456789012345678

# 2) Roles (si no los creas con /setupverificacion)
/config clave:verified_role_id   valor:ID_DEL_ROL_VERIFICADO
/config clave:unverified_role_id valor:ID_DEL_ROL_SIN_VERIFICAR

# 3) Oculta todos los canales a los no verificados (permisos reales)
/aplicarbloqueo

# 4) Publica el panel de verificación
/panelverificacion
```

> El bot aplica los permisos directamente: pone `Ver canal = denegado` al rol
> *Sin verificar* en todos los canales salvo el de verificación. Así no depende de
> que configures los permisos a mano. `/quitarbloqueo` lo revierte.

### 4. Miembros que YA están en el servidor

Los usuarios ya presentes también deben verificar. Al arrancar el bot se hace
automáticamente si `enforce_on_start = true`, y puedes forzarlo cuando quieras:

```
/sincronizarverificacion
```

Omiten la verificación los bots, el dueño, los que tengan un rol exento y los ya
verificados. Define los roles exentos (staff) con:

```
/config clave:verify_exempt_role_ids valor:ID_ROL_STAFF,ID_ROL_ADMIN
```

### 5. Auto-roles

Roles que se entregan automáticamente al entrar (bienvenida) y al verificar:

```
/autoroles accion:Añadir  rol:@Miembro
/autoroles accion:Ver
```

### 6. Modo de verificación

```
/config clave:verify_in_channel valor:true    # verifica con el botón en el canal (sin web)
/config clave:verify_in_channel valor:false   # obliga a pasar por la web (captura IP)
/config clave:lock_channels    valor:true     # ocultar canales a los no verificados
/config clave:enforce_on_start valor:true     # obligar a los ya presentes al arrancar
```

### 7. Umbrales (opcionales)

```
/config clave:raid_join_threshold valor:10
/config clave:min_account_age_days valor:7
/config clave:spam_msg_threshold  valor:6
/config clave:spam_action         valor:timeout
```
Revisa todo con `/opciones`.

---

## Comandos

| Comando | Descripción |
|---|---|
| `/invites [usuario]` | Estadísticas de invitaciones |
| `/topinvites` | Ranking de invitadores |
| `/invitaciones_de <usuario>` | Quién invitó a un usuario |
| `/canales <tipo> <canal>` | Asignar canal de registro |
| `/config <clave> <valor>` | Ajustar configuración |
| `/opciones` | Ver configuración actual |
| `/canalverificacion [canal] [id_canal]` | Fija el canal único de verificación (por canal o ID) |
| `/panelverificacion` | Publica el panel en el canal configurado |
| `/setupverificacion [canal]` | Monta todo: roles + canal + bloqueo + panel |
| `/sincronizarverificacion` | Obliga a verificar a TODOS los miembros actuales |
| `/aplicarbloqueo` | Oculta todos los canales a los no verificados |
| `/quitarbloqueo` | Restaura la visibilidad de los canales |
| `/autoroles <acción> [rol]` | Gestiona los roles automáticos |
| `/verificar <usuario>` | Forzar verificación |
| `/quitarverificacion <usuario>` | Revertir verificación |
| `/raidmode <bool>` | Activar/desactivar raid a mano |
| `/confiar` / `/noconfiar` | Exención de anti-nuke |
| `/eventos [n]` | Últimos eventos de seguridad |
| `/ip <usuario>` | Última IP registrada |
| `/seguridad` | Resumen del sistema |

---

## Flujo de seguridad

1. **Entrada** → se identifica el invitador, se registra en el canal de invitaciones.
2. **Cuenta nueva** → marcada como sospechosa, aviso al canal de seguridad y expulsión (si está activado).
3. **Avalancha de entradas** → modo raid: canales bloqueados + verificación reforzada.
4. **Sin verificar** → roles retirados y **todos los canales ocultos por permisos**: solo ve el canal de verificación (también los miembros ya presentes).
5. **Verifica** (botón en el canal, o web si `verify_in_channel=false`) → recibe el rol verificado, sus auto-roles y acceso a todos los canales.
6. **Spam / nuke** → sanción automática + registro con IP en el canal de seguridad.

---

## Exponer el servidor de verificación

Para que la captura de IP funcione, el usuario debe llegar a tu servidor web. Opciones:

- **Reverse proxy** (Nginx/Caddy) con HTTPS: `proxy_pass http://127.0.0.1:8080`.
- **Túnel** para pruebas: `cloudflared tunnel --url http://localhost:8080` o `ngrok http 8080`.
- En producción usa HTTPS y actualiza `WEB_VERIFY_PUBLIC_URL`.

Con Cloudflare/nginx, activa `TRUST_PROXY_HEADERS=true` para leer la IP real del cliente.


## Funciones añadidas en esta versión

- **Anti-nuke**: inspecciona el registro de auditoría para detectar eliminaciones repetidas de canales/roles y baneos. `/confiar` y `/noconfiar` permiten excluir usuarios. Umbral editable con `/config clave:antinuke_threshold valor:3`; acciones `timeout` o `ban`. El sistema no puede revertir automáticamente todas las acciones y depende de que Discord entregue los eventos de auditoría.
- **Tickets privados**: `/paneltickets` publica el botón para abrir tickets y `/ticketconfig` permite configurar categoría y rol de soporte. Cerrar ticket registra el evento y elimina el canal.
- **AutoMod configurable**: `/automodconfig` controla enlaces, invitaciones, palabras bloqueadas (separadas por `|`), límite de menciones y acción. Para desactivar límite de menciones usa `0`.
- **Panel web**: activa `DASHBOARD_ENABLED=true`, define `DASHBOARD_PASSWORD` y abre `http://127.0.0.1:8090`. Usa autenticación HTTP Basic en el navegador. Por seguridad escucha en localhost; no lo publiques directamente en Internet. Si lo expones mediante un proxy, usa HTTPS, control de acceso y configuración segura.
- **Exportación**: `/exportarconfig` descarga un JSON de configuración y eventos recientes; solo administradores. No incluye secretos.
- **Bienvenida/despedida y auto-roles**: usa `/config` para `welcome_channel_id`, `welcome_message`, `goodbye_channel_id`, `goodbye_message` y `auto_role_ids`. Variables disponibles en mensajes: `{mention}`, `{name}`, `{guild}` (despedida usa `{name}` y `{guild}`). `auto_role_ids` acepta IDs separados por coma.
- **Auditoría avanzada**: cambios de roles, apodos, canales, roles y baneos quedan registrados en eventos y, si se configuró, en el canal `log_mod_channel`.

### Recomendaciones de seguridad

1. Activa solo los permisos necesarios; coloca el rol del bot por encima de los roles que administra.
2. Empieza con acciones `delete` o `timeout` antes de permitir baneos automáticos.
3. Configura un canal de seguridad privado para los registros.
4. Las copias de seguridad incluyen IDs de configuración y eventos; guárdalas con acceso restringido.
5. El panel web está desactivado por defecto y debe mantenerse local salvo que configures un proxy HTTPS correctamente.
6. La auditoría de Discord puede tardar en actualizarse; Anti-nuke es una capa de detección, no una garantía absoluta.

### Nuevos comandos

| Comando | Uso |
|---|---|
| `/paneltickets` | Publicar panel de tickets |
| `/ticketconfig` | Configurar categoría y rol de soporte |
| `/automodconfig` | Ajustar filtros AutoMod |
| `/exportarconfig` | Exportar ajustes y eventos |
| `/confiar` / `/noconfiar` | Gestionar exenciones anti-nuke |

La primera sincronización de slash commands puede tardar si usas comandos globales. Define `GUILD_ID` para sincronización de pruebas en un servidor concreto.

## Pruebas de validación

Se comprueba la sintaxis de todos los archivos Python con `python -m compileall`. Para validar el funcionamiento completo, instala dependencias, configura un bot de prueba y prueba comandos/eventos en un servidor privado antes de usarlo en producción.
