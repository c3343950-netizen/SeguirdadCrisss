
from __future__ import annotations

import asyncio
import html
from typing import Optional

from flask import Flask, request

import config


def _client_ip() -> str:
    if config.TRUST_PROXY_HEADERS:
        fwd = request.headers.get("X-Forwarded-For")
        if fwd:
            return fwd.split(",")[0].strip()
    return request.remote_addr or "N/D"


PAGE_OK = """<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verificacion completada</title>
<style>body{{background:#1e1f22;color:#dbdee1;font-family:Arial,sans-serif;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0}}
.card{{background:#2b2d31;padding:40px 50px;border-radius:16px;text-align:center;max-width:520px}}
h1{{color:#57f287;font-size:22px}} p{{color:#b5bac1}}</style></head><body><div class="card">
<h1>✅ Verificacion completada</h1>
<p>Tu acceso al servidor ha sido concedido. Ya puedes cerrar esta pestaña y volver a Discord.</p>
</div></body></html>"""

PAGE_ERR = """<!doctype html><html lang="es"><head><meta charset="utf-8">
<title>Enlace invalido</title></head><body style="background:#1e1f22;color:#ed4245;font-family:Arial">
<div style="text-align:center;margin-top:20vh"><h2>❌ {msg}</h2></div></body></html>"""


def create_app(bot) -> Flask:
    app = Flask(__name__)

    @app.get("/health")
    def health():
        return {"ok": True}

    @app.get("/verify/<token>")
    def verify(token: str):
        ip = _client_ip()
        ua = request.headers.get("User-Agent", "N/D")

        # 1) localizar la verificacion por token
        fut = asyncio.run_coroutine_threadsafe(
            bot.db.find_verification_by_token(token), bot.loop
        )
        try:
            record = fut.result(timeout=5)
        except Exception:
            record = None

        if not record:
            return PAGE_ERR.format(msg="Enlace invalido o expirado."), 404

        if record["status"] == "verified":
            return PAGE_OK

        # 2) completar la verificacion (captura IP + roles)
        cog = bot.get_cog("Verification")
        if cog is None:
            return PAGE_ERR.format(msg="Servicio de verificacion no disponible."), 503

        fut = asyncio.run_coroutine_threadsafe(
            cog.complete(record["guild_id"], record["user_id"], ip=ip, user_agent=ua), bot.loop
        )
        try:
            ok = fut.result(timeout=10)
        except Exception:
            ok = False

        if not ok:
            return PAGE_ERR.format(msg="No se pudo completar la verificacion."), 500
        return PAGE_OK

    return app


def run_server(bot) -> None:
    """Arranca el servidor web en un hilo aparte (usando waitress en produccion)."""
    app = create_app(bot)
    try:
        from waitress import serve
        serve(app, host=config.WEB_VERIFY_HOST, port=config.WEB_VERIFY_PORT, threads=4)
    except ImportError:
        app.run(host=config.WEB_VERIFY_HOST, port=config.WEB_VERIFY_PORT, threaded=True)
