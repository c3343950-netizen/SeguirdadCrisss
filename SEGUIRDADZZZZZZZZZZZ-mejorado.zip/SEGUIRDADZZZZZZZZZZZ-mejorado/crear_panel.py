"""
Publica el panel de verificacion (embed + boton persistente 'verify:start')
en un canal concreto y lo registra como `verify_panel_channel` en la BD.

Uso:
    py crear_panel.py                # usa el canal por defecto (#verifir)
    py crear_panel.py <channel_id>   # canal indicado

Requiere que el bot este invitado al servidor y con permiso de enviar mensajes.
El boton funciona aunque los slash commands no esten sincronizados, porque la
vista es persistente (custom_id 'verify:start') y la registra el bot al cargar
el cog de verificacion.
"""
from __future__ import annotations

import datetime as _dt
import json
import sqlite3
import sys
import urllib.error
import urllib.request

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import config

API = "https://discord.com/api/v10"

# Canal #verifir del servidor CAILE CHEATS ZZZ
DEFAULT_CHANNEL_ID = 1551710556627673118


def _request(method: str, path: str, payload: dict | None = None):
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(
        f"{API}{path}",
        data=data,
        method=method,
        headers={
            "Authorization": f"Bot {config.TOKEN}",
            "Content-Type": "application/json",
            "User-Agent": "DiscordBot (panel, 1.0)",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        try:
            body = json.loads(body)
        except Exception:
            pass
        return e.code, body


def _get(path: str):
    return _request("GET", path)


def build_payload(guild_name: str) -> dict:
    embed = {
        "title": "Verificar Usari@s",
        "description": (
            f"Para ver el resto de canales de **{guild_name}** debes verificarte.\n"
            "Pulsa el boton de abajo. Si la verificacion web esta activa,"
            "queda registrada en los registros de seguridad."
        ),
        "color": 0x5865F2,
        "timestamp": _dt.datetime.now(_dt.timezone.utc).isoformat(),
    }
    components = [
        {
            "type": 1,  # ACTION_ROW
            "components": [
                {
                    "type": 2,  # BUTTON
                    "style": 3,  # SUCCESS (verde)
                    "label": "Verificar",
                    "emoji": {"name": "✅"},
                    "custom_id": "verify:start",
                }
            ],
        }
    ]
    return {"embeds": [embed], "components": components}


def set_db_setting(guild_id: int, key: str, value: int) -> None:
    """Registra el canal del panel en bot.db (por si el bot lo consulta)."""
    try:
        conn = sqlite3.connect(config.DB_PATH, timeout=5)
        conn.execute(
            "INSERT INTO settings(guild_id, key, value) VALUES(?,?,?) "
            "ON CONFLICT(guild_id, key) DO UPDATE SET value=excluded.value",
            (guild_id, key, str(value)),
        )
        conn.commit()
        conn.close()
        print(f"[db] {key} = {value} (guild {guild_id})")
    except sqlite3.Error as e:
        print(f"[db] aviso: no pude escribir en la BD ({e}). "
              f"Usa el comando /canalverificacion en Discord si hace falta.")


def main() -> None:
    if not config.TOKEN:
        raise SystemExit("Falta DISCORD_TOKEN en el .env")

    channel_id = int(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_CHANNEL_ID
    print(f"Canal destino: {channel_id}")

    st, ch = _get(f"/channels/{channel_id}")
    if st != 200:
        raise SystemExit(f"No puedo ver el canal {channel_id}: HTTP {st} {ch}")
    guild_id = int(ch["guild_id"])
    print(f"Canal '#{ch['name']}' en guild {guild_id}")

    st, guild = _get(f"/guilds/{guild_id}")
    guild_name = guild.get("name", "el servidor") if st == 200 else "el servidor"

    st, msg = _request("POST", f"/channels/{channel_id}/messages", build_payload(guild_name))
    if st not in (200, 201):
        print(f"ERROR al publicar el panel: HTTP {st} {msg}")
        if st == 403:
            print("  -> Falta permiso 'Enviar mensajes' en ese canal para el bot.")
        return

    print(f"OK panel publicado. message id={msg.get('id')}")
    set_db_setting(guild_id, "verify_panel_channel", channel_id)


if __name__ == "__main__":
    main()
