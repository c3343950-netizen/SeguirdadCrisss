
import os
from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes", "si", "on")


def _int(name: str, default: int = 0) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except (ValueError, AttributeError):
        return default


# --- Bot ---
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
GUILD_ID = _int("GUILD_ID", 0)
PREFIX = os.getenv("PREFIX", "!")

# --- Verificacion web (captura de IP) ---
WEB_VERIFY_ENABLED = _bool("WEB_VERIFY_ENABLED", False)
WEB_VERIFY_HOST = os.getenv("WEB_VERIFY_HOST", "0.0.0.0")
WEB_VERIFY_PORT = _int("WEB_VERIFY_PORT", 8080)
WEB_VERIFY_PUBLIC_URL = os.getenv("WEB_VERIFY_PUBLIC_URL", "http://127.0.0.1:8080").rstrip("/")
VERIFY_SECRET = os.getenv("VERIFY_SECRET", "")
TRUST_PROXY_HEADERS = _bool("TRUST_PROXY_HEADERS", False)

# --- Base de datos ---
DB_PATH = os.getenv("DB_PATH", "bot.db")

# ================= VALORES POR DEFECTO (editables con /config) =================
DEFAULTS = {
    # Anti-raid
    "raid_join_threshold": "10",      # joins para activar modo raid
    "raid_window_seconds": "15",      # ventana de tiempo para contar joins
    "raid_cooldown_seconds": "300",   # duracion del modo raid
    "min_account_age_days": "7",      # edad minima de cuenta (0 = desactivado)
    "raid_kick_new_accounts": "true", # expulsar cuentas nuevas durante raid

    # Anti-spam
    "spam_msg_threshold": "6",        # mensajes
    "spam_msg_window": "5",           # en X segundos
    "spam_mention_limit": "6",        # menciones por mensaje
    "spam_action": "timeout",         # delete | timeout | kick | ban
    "spam_timeout_minutes": "10",

    # Anti-nuke
    "antinuke_enabled": "true",
    "antinuke_action": "timeout",
    "antinuke_threshold": "3",
    "automod_links": "false",
    "automod_invites": "true",
    "automod_mention_limit": "6",
    "automod_blocked_words": "",
    "automod_action": "delete",
    "welcome_channel_id": "0",
    "welcome_message": "¡Bienvenido {mention} a {guild}!",
    "goodbye_channel_id": "0",
    "goodbye_message": "{name} ha salido del servidor.",
    "ticket_category_id": "0",
    "ticket_staff_role_id": "0",

    # Verificacion
    "verification_enabled": "true",
    "verified_role_id": "0",
    "unverified_role_id": "0",
    "gate_other_roles": "true",        # quitar roles hasta verificar
    "lock_channels": "true",           # ocultar TODOS los canales a los no verificados
    "verify_in_channel": "true",       # verificar con el boton en el mismo canal (sin web)
    "auto_role_ids": "0",              # roles automaticos al entrar (ids separados por coma)
    "verify_exempt_role_ids": "0",     # roles exentos de verificacion (0 = SIN excepciones)
    "enforce_on_start": "true",        # obligar a los ya presentes a verificar al arrancar
    "autoverify_bots": "true",         # los bots se verifican solos (no quedan bloqueados)

    # Canales de registro (0 = desactivado)
    "log_join_channel": "0",
    "log_leave_channel": "0",
    "log_invite_channel": "0",
    "log_raid_channel": "0",
    "log_security_channel": "0",
    "log_verify_channel": "0",
    "log_mod_channel": "0",

    # Canal donde vive el panel de verificacion (tambien es el unico canal visible sin verificar)
    "verify_panel_channel": "0",
}
