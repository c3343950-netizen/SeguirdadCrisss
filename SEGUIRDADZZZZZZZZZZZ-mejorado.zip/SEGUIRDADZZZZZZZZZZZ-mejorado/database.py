from __future__ import annotations

import time
from typing import Any, Optional

import aiosqlite

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    guild_id INTEGER NOT NULL,
    key      TEXT NOT NULL,
    value    TEXT NOT NULL,
    PRIMARY KEY (guild_id, key)
);

CREATE TABLE IF NOT EXISTS invite_joins (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id   INTEGER NOT NULL,
    member_id  INTEGER NOT NULL,
    inviter_id INTEGER,
    code       TEXT,
    fake       INTEGER NOT NULL DEFAULT 0,
    joined_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS invite_stats (
    guild_id   INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    joins      INTEGER NOT NULL DEFAULT 0,
    leaves     INTEGER NOT NULL DEFAULT 0,
    fake       INTEGER NOT NULL DEFAULT 0,
    rejoin     INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS verifications (
    guild_id    INTEGER NOT NULL,
    user_id     INTEGER NOT NULL,
    token       TEXT,
    status      TEXT NOT NULL DEFAULT 'pending',
    ip          TEXT,
    user_agent  TEXT,
    created_at  INTEGER NOT NULL,
    verified_at INTEGER,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS security_events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id   INTEGER NOT NULL,
    user_id    INTEGER,
    kind       TEXT NOT NULL,
    detail     TEXT,
    ip         TEXT,
    created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_secevt_guild ON security_events(guild_id, created_at);
CREATE INDEX IF NOT EXISTS idx_invjoins_member ON invite_joins(guild_id, member_id);
"""


class Database:
    def __init__(self, path: str | None = None) -> None:
        self.path = path or config.DB_PATH
        self.conn: Optional[aiosqlite.Connection] = None

    async def connect(self) -> None:
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.executescript(SCHEMA)
        await self.conn.commit()

    async def close(self) -> None:
        if self.conn:
            await self.conn.close()

    # ---------------- Settings ----------------
    async def get_setting(self, guild_id: int, key: str) -> str:
        defaults = config.DEFAULTS.get(key, "")
        if not self.conn:
            return defaults
        async with self.conn.execute(
            "SELECT value FROM settings WHERE guild_id=? AND key=?", (guild_id, key)
        ) as cur:
            row = await cur.fetchone()
        return row["value"] if row else defaults

    async def get_int(self, guild_id: int, key: str) -> int:
        try:
            return int(await self.get_setting(guild_id, key))
        except (ValueError, TypeError):
            return 0

    async def get_bool(self, guild_id: int, key: str) -> bool:
        return (await self.get_setting(guild_id, key)).strip().lower() in ("1", "true", "yes", "on")

    async def set_setting(self, guild_id: int, key: str, value: Any) -> None:
        if isinstance(value, bool):
            value = "true" if value else "false"
        await self.conn.execute(
            "INSERT INTO settings(guild_id, key, value) VALUES(?,?,?) "
            "ON CONFLICT(guild_id, key) DO UPDATE SET value=excluded.value",
            (guild_id, key, str(value)),
        )
        await self.conn.commit()

    async def all_settings(self, guild_id: int) -> dict:
        async with self.conn.execute(
            "SELECT key, value FROM settings WHERE guild_id=?", (guild_id,)
        ) as cur:
            rows = await cur.fetchall()
        merged = dict(config.DEFAULTS)
        merged.update({r["key"]: r["value"] for r in rows})
        return merged

    # ---------------- Invitaciones ----------------
    async def add_invite_join(
        self, guild_id: int, member_id: int, inviter_id: Optional[int], code: Optional[str], fake: bool
    ) -> None:
        await self.conn.execute(
            "INSERT INTO invite_joins(guild_id, member_id, inviter_id, code, fake, joined_at) "
            "VALUES(?,?,?,?,?,?)",
            (guild_id, member_id, inviter_id, code, 1 if fake else 0, int(time.time())),
        )
        await self.conn.commit()

    async def count_previous_joins(self, guild_id: int, member_id: int) -> int:
        async with self.conn.execute(
            "SELECT COUNT(*) AS c FROM invite_joins WHERE guild_id=? AND member_id=?",
            (guild_id, member_id),
        ) as cur:
            row = await cur.fetchone()
        return row["c"]

    async def bump_invite_stat(self, guild_id: int, user_id: int, field: str, amount: int = 1) -> None:
        assert field in ("joins", "leaves", "fake", "rejoin")
        await self.conn.execute(
            "INSERT INTO invite_stats(guild_id, user_id) VALUES(?,?) "
            "ON CONFLICT(guild_id, user_id) DO NOTHING",
            (guild_id, user_id),
        )
        await self.conn.execute(
            f"UPDATE invite_stats SET {field}={field}+? WHERE guild_id=? AND user_id=?",
            (amount, guild_id, user_id),
        )
        await self.conn.commit()

    async def get_invite_stats(self, guild_id: int, user_id: int) -> dict:
        async with self.conn.execute(
            "SELECT joins, leaves, fake, rejoin FROM invite_stats WHERE guild_id=? AND user_id=?",
            (guild_id, user_id),
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return {"joins": 0, "leaves": 0, "fake": 0, "rejoin": 0, "real": 0}
        data = dict(row)
        data["real"] = data["joins"] - data["leaves"] - data["fake"]
        return data

    async def top_inviters(self, guild_id: int, limit: int = 10) -> list:
        async with self.conn.execute(
            "SELECT user_id, joins, leaves, fake, (joins-leaves-fake) AS real "
            "FROM invite_stats WHERE guild_id=? ORDER BY real DESC LIMIT ?",
            (guild_id, limit),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]

    async def last_inviter_of(self, guild_id: int, member_id: int) -> Optional[int]:
        async with self.conn.execute(
            "SELECT inviter_id FROM invite_joins WHERE guild_id=? AND member_id=? "
            "ORDER BY id DESC LIMIT 1",
            (guild_id, member_id),
        ) as cur:
            row = await cur.fetchone()
        return row["inviter_id"] if row else None

    # ---------------- Verificacion ----------------
    async def upsert_verification(self, guild_id: int, user_id: int, token: str, status: str = "pending") -> None:
        await self.conn.execute(
            "INSERT INTO verifications(guild_id, user_id, token, status, created_at) VALUES(?,?,?,?,?) "
            "ON CONFLICT(guild_id, user_id) DO UPDATE SET token=excluded.token, status=excluded.status, "
            "created_at=excluded.created_at",
            (guild_id, user_id, token, status, int(time.time())),
        )
        await self.conn.commit()

    async def complete_verification(self, guild_id: int, user_id: int, ip: str, user_agent: str) -> None:
        await self.conn.execute(
            "UPDATE verifications SET status='verified', ip=?, user_agent=?, verified_at=? "
            "WHERE guild_id=? AND user_id=?",
            (ip, user_agent, int(time.time()), guild_id, user_id),
        )
        await self.conn.commit()

    async def find_verification_by_token(self, token: str) -> Optional[dict]:
        async with self.conn.execute(
            "SELECT guild_id, user_id, status FROM verifications WHERE token=?", (token,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    async def verification_status(self, guild_id: int, user_id: int) -> Optional[str]:
        async with self.conn.execute(
            "SELECT status FROM verifications WHERE guild_id=? AND user_id=?",
            (guild_id, user_id),
        ) as cur:
            row = await cur.fetchone()
        return row["status"] if row else None

    async def last_ip(self, guild_id: int, user_id: int) -> Optional[str]:
        async with self.conn.execute(
            "SELECT ip FROM verifications WHERE guild_id=? AND user_id=? AND ip IS NOT NULL",
            (guild_id, user_id),
        ) as cur:
            row = await cur.fetchone()
        return row["ip"] if row else None

    # ---------------- Eventos de seguridad ----------------
    async def add_security_event(
        self, guild_id: int, kind: str, user_id: Optional[int] = None, detail: str = "", ip: Optional[str] = None
    ) -> None:
        await self.conn.execute(
            "INSERT INTO security_events(guild_id, user_id, kind, detail, ip, created_at) VALUES(?,?,?,?,?,?)",
            (guild_id, user_id, kind, detail, ip, int(time.time())),
        )
        await self.conn.commit()

    async def recent_security_events(self, guild_id: int, limit: int = 20) -> list:
        async with self.conn.execute(
            "SELECT user_id, kind, detail, ip, created_at FROM security_events "
            "WHERE guild_id=? ORDER BY id DESC LIMIT ?",
            (guild_id, limit),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]
