"""Panel administrativo local. Mantener DASHBOARD_HOST en 127.0.0.1 y usar un proxy HTTPS si se publica."""
import os, hmac
from flask import Flask, request, jsonify, Response
from waitress import serve
app=Flask(__name__)
BOT=None
HTML="""<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Seguridad Discord</title><style>body{font:16px system-ui;max-width:900px;margin:3rem auto;padding:0 1rem;background:#10131b;color:#edf2ff}input,button{padding:.7rem;margin:.25rem;border-radius:8px;border:1px solid #566}button{cursor:pointer;background:#5865f2;color:white}pre{white-space:pre-wrap;background:#1c2230;padding:1rem;border-radius:10px}</style><h1>🛡️ Panel de seguridad</h1><p>Introduce el ID del servidor y consulta la configuración.</p><input id="guild" placeholder="ID del servidor"><button onclick="loadData()">Consultar</button><pre id="out">Panel listo.</pre><h2>Actualizar opción</h2><input id="key" placeholder="clave"><input id="val" placeholder="valor"><button onclick="saveData()">Guardar</button><script>async function loadData(){let r=await fetch('/api/settings/'+document.querySelector('#guild').value);document.querySelector('#out').textContent=JSON.stringify(await r.json(),null,2)}async function saveData(){let r=await fetch('/api/settings/'+document.querySelector('#guild').value,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:document.querySelector('#key').value,value:document.querySelector('#val').value})});document.querySelector('#out').textContent=JSON.stringify(await r.json(),null,2)}</script></html>"""
def auth():
    expected=os.getenv('DASHBOARD_PASSWORD','')
    provided=request.headers.get('X-Dashboard-Password','') or (request.authorization.password if request.authorization else '')
    return bool(expected) and hmac.compare_digest(expected,provided)
@app.before_request
def protect():
    if not auth(): return Response('Autenticación requerida.',401,{'WWW-Authenticate':'Basic realm=\"Discord Security Dashboard\"'})
@app.get('/')
def home(): return HTML
@app.get('/api/health')
def health(): return jsonify({'ok':bool(BOT and BOT.is_ready())})
@app.get('/api/settings/<int:guild_id>')
def settings(guild_id):
    import asyncio
    if not BOT or not BOT.get_guild(guild_id): return jsonify({'error':'Servidor no encontrado'}),404
    future=__import__('concurrent.futures').futures.Future()
    async def get(): return await BOT.db.all_settings(guild_id)
    f=asyncio.run_coroutine_threadsafe(get(),BOT.loop)
    try: return jsonify({'guild_id':guild_id,'settings':f.result(timeout=8)})
    except Exception: return jsonify({'error':'No se pudo consultar la base de datos'}),500
@app.get('/api/stats/<int:guild_id>')
def stats(guild_id):
    import asyncio
    guild=BOT.get_guild(guild_id) if BOT else None
    if not guild: return jsonify({'error':'Servidor no encontrado'}),404
    async def get(): return await BOT.db.recent_security_events(guild_id,20)
    f=asyncio.run_coroutine_threadsafe(get(),BOT.loop)
    try: events=f.result(timeout=8)
    except Exception: return jsonify({'error':'No se pudieron consultar los eventos'}),500
    return jsonify({'guild_id':guild_id,'guild_name':guild.name,'members':guild.member_count,'latency_ms':round(BOT.latency*1000),'recent_events':events})
@app.post('/api/settings/<int:guild_id>')
def update(guild_id):
    import asyncio
    if not BOT or not BOT.get_guild(guild_id): return jsonify({'error':'Servidor no encontrado'}),404
    body=request.get_json(silent=True) or {}; key=body.get('key',''); value=body.get('value','')
    from config import DEFAULTS
    if key not in DEFAULTS or not isinstance(value,(str,int,bool)) or len(str(value))>500: return jsonify({'error':'Clave o valor no permitido'}),400
    f=asyncio.run_coroutine_threadsafe(BOT.db.set_setting(guild_id,key,value),BOT.loop)
    try: f.result(timeout=8); return jsonify({'ok':True,'key':key,'value':value})
    except Exception: return jsonify({'error':'No se pudo guardar'}),500
def run_server(bot):
    global BOT; BOT=bot
    host=os.getenv('DASHBOARD_HOST','127.0.0.1'); port=int(os.getenv('DASHBOARD_PORT','8090'))
    if not os.getenv('DASHBOARD_PASSWORD'): raise RuntimeError('DASHBOARD_PASSWORD debe configurarse para activar el panel')
    serve(app,host=host,port=port,threads=4)
