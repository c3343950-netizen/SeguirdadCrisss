
from __future__ import annotations

import time
from typing import Optional

import discord

import config


def fmt_ts(epoch: int | float | None = None) -> str:
    epoch = epoch or time.time()
    return f"<t:{int(epoch)}:F> (<t:{int(epoch)}:R>)"


def account_age_days(member: discord.Member) -> int:
    return (discord.utils.utcnow() - member.created_at).days


async def send_log(
    guild: discord.Guild,
    db,
    setting_key: str,
    embed: discord.Embed,
) -> Optional[discord.Message]:
    """Envia un embed al canal configurado en `setting_key`. Devuelve el mensaje o None."""
    channel_id = await db.get_int(guild.id, setting_key)
    if not channel_id:
        return None
    channel = guild.get_channel(channel_id)
    if channel is None or not isinstance(channel, discord.abc.Messageable):
        return None
    try:
        return await channel.send(embed=embed)
    except (discord.Forbidden, discord.HTTPException):
        return None


def base_embed(title: str, color: int = 0x2F3136) -> discord.Embed:
    e = discord.Embed(title=title, color=color, timestamp=discord.utils.utcnow())
    return e


def user_line(user: discord.abc.User) -> str:
    return f"{user.mention} (`{user.id}`)\n{user}"


IP_UNKNOWN = "Desconocida (no paso por la verificacion web)"
