
from __future__ import annotations

import asyncio
import sys
import threading

# La consola de Windows (cp1252) revienta al imprimir nombres de servidor/canal
# con caracteres no ASCII (ej. "𝐶𝐴𝐼𝐿𝐸..."). Forzamos UTF-8 con reemplazo.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import discord
from discord.ext import commands

import config
from database import Database

COGS = [
    "cogs.invites", "cogs.antiraid", "cogs.verification", "cogs.security", "cogs.setup",
    "cogs.antinuke", "cogs.tickets", "cogs.automod", "cogs.audit", "cogs.backup",
]
intents = discord.Intents.default()
intents.members = True            # necesario para joins/leaves e invitaciones
intents.message_content = True    # necesario para anti-spam
intents.guilds = True
intents.invites = True
intents.moderation = True         # recibir eventos de moderacion/audit log


class SecurityBot(commands.Bot):
    def __init__(self) -> None:
        super().__init__(command_prefix=config.PREFIX, intents=intents, help_command=None)
        self.db = Database()

    async def setup_hook(self) -> None:
        await self.db.connect()
        for ext in COGS:
            await self.load_extension(ext)
            print(f"[cogs] Cargado: {ext}")

        # sincronizar slash commands
        try:
            if config.GUILD_ID:
                guild = discord.Object(id=config.GUILD_ID)
                self.tree.copy_global_to(guild=guild)
                synced = await self.tree.sync(guild=guild)
            else:
                synced = await self.tree.sync()
            print(f"[sync] {len(synced)} comandos sincronizados.")
        except Exception as e:  # noqa: BLE001
            print(f"[sync] Error: {e}")

    async def on_ready(self) -> None:
        print(f"[bot] Conectado como {self.user} (ID {self.user.id})")
        await self.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name="Segurity 24/7 👑")
        )


async def main() -> None:
    if not config.TOKEN:
        raise SystemExit("Falta DISCORD_TOKEN en el archivo .env")

    bot = SecurityBot()

    # Panel administrativo separado, protegido por contraseña. Desactivado por defecto.
    if __import__("os").getenv("DASHBOARD_ENABLED", "false").lower() in ("1", "true", "yes"):
        import dashboard
        dt = threading.Thread(target=dashboard.run_server, args=(bot,), daemon=True)
        dt.start()
        print("[dashboard] Panel administrativo iniciado")

    # arrancar servidor web de verificacion en un hilo aparte
    if config.WEB_VERIFY_ENABLED:
        import webverify

        t = threading.Thread(target=webverify.run_server, args=(bot,), daemon=True)
        t.start()
        print(f"[web] Verificacion escuchando en {config.WEB_VERIFY_HOST}:{config.WEB_VERIFY_PORT}")

    try:
        await bot.start(config.TOKEN)
    finally:
        await bot.db.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[bot] Detenido.")
